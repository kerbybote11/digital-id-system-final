<?php
declare(strict_types=1);

/**
 * DEV/TEST ONLY -- creates admin@gmail.com, student@gmail.com, scanner@gmail.com using the
 * app's own PDO connection and password_hash(PASSWORD_BCRYPT).
 * Alternative to database/seed_test_accounts.sql; safe to re-run.
 *
 * Usage (CLI only):  php tools/seed_test_accounts.php
 * Delete this file (and the test accounts) before any real deployment.
 */
if (PHP_SAPI !== 'cli') {
    die('This script must be run from the command line.');
}

require_once __DIR__ . '/../config/database.php';

$pdo = getDBConnection();

$accounts = [
    ['admin@gmail.com',   'admin123',   'ADMIN'],
    ['student@gmail.com', 'student123', 'STUDENT'],
    ['scanner@gmail.com', 'scanner123', 'SCANNER'],
];

$pdo->beginTransaction();
try {
    $upsert = $pdo->prepare(
        'INSERT INTO users (username, password_hash, role, status)
         VALUES (?, ?, ?, \'ACTIVE\')
         ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash),
                                 role = VALUES(role), status = \'ACTIVE\''
    );
    foreach ($accounts as [$username, $password, $role]) {
        $upsert->execute([$username, password_hash($password, PASSWORD_BCRYPT), $role]);
    }

    $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ?');
    $stmt->execute(['student@gmail.com']);
    $studentUserId = (int) $stmt->fetchColumn();

    $pdo->prepare(
        'INSERT INTO students (user_id, student_id, first_name, last_name, course, year_level, status, current_status)
         VALUES (?, \'TEST-0001\', \'Test\', \'Student\', \'BS Information Technology\', \'3rd Year\', \'ACTIVE\', \'OUT\')
         ON DUPLICATE KEY UPDATE status = \'ACTIVE\', current_status = \'OUT\''
    )->execute([$studentUserId]);

    $pdo->commit();
    echo "Test accounts ready: admin@gmail.com, student@gmail.com, scanner@gmail.com\n";
} catch (Throwable $e) {
    $pdo->rollBack();
    fwrite(STDERR, 'Seeding failed: ' . $e->getMessage() . "\n");
    exit(1);
}
