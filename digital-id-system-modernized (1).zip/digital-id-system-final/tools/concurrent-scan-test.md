# Concurrent scan test (selected-action scanner)

## Automated (recommended)
`php tools/test-scanner-actions.php` runs the real server logic against your
MySQL database, including Test 12: 8 PHP processes released at the same
instant against the same student (8 x IN, then 8 x OUT, then a mixed 4 IN +
4 OUT run). It creates and removes its own temporary rows.

Expected: exactly one SUCCESS_IN and seven ALREADY_IN, then exactly one
SUCCESS_OUT and seven ALREADY_OUT; the mixed run must produce a transaction
log that strictly alternates IN, OUT, IN, ... with no duplicate consecutive
types and a final students.current_status equal to the last logged type.

## Manual (optional, with curl)
`scanner/verify.php` now expects an explicit `action` and returns JSON.

1. Log in as the scanner in a browser, open DevTools -> Application ->
   Cookies and copy `PHPSESSID`; view the page source of
   `scanner/scanner.php` and copy `data-csrf-token`.
2. Generate a QR as a student and copy the "Token for manual entry".
3. Fire two requests at the same time (same student, same action):

       curl -s -b "PHPSESSID=<scanner_session>" \
         -d "csrf_token=<csrf>&action=IN&qr_token=<raw_token>" \
         http://localhost/digital-id-system-final/scanner/verify.php &
       curl -s -b "PHPSESSID=<scanner_session>" \
         -d "csrf_token=<csrf>&action=IN&qr_token=<raw_token>" \
         http://localhost/digital-id-system-final/scanner/verify.php &
       wait

   Expected: one response with `"code":"SUCCESS_IN"` and one with
   `"code":"ALREADY_IN"`; in phpMyAdmin exactly one new IN row in
   `access_transactions`, and `students.current_status = 'IN'`.
