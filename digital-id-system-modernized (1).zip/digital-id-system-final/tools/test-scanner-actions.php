<?php
declare(strict_types=1);

/**
 * DEV-ONLY backend test for the selected-action scanner logic.
 *
 * Runs the REAL performScanAction() / processAccessTransition() against your
 * real MySQL database (config/database.php). It creates temporary rows
 * (usernames "zzscantest*", student IDs "ZZTEST-*"), runs every case, then
 * deletes everything it created. Your own data is not touched.
 *
 * Usage (from the project root, with MySQL running and schema imported):
 *     php tools/test-scanner-actions.php
 *
 * Exit code 0 = all passed, 1 = at least one failure.
 * The web server blocks this folder via tools/.htaccess; CLI only.
 */
if (PHP_SAPI !== 'cli') {
    die('This script must be run from the command line.');
}

require_once __DIR__ . '/../includes/qr.php';
require_once __DIR__ . '/../includes/access.php';
require_once __DIR__ . '/../config/database.php';

// ---------------------------------------------------------------------
// Child mode: one simulated scanner request, fired at a shared start time
// so several processes hit the database at (nearly) the same instant.
// ---------------------------------------------------------------------
if (($argv[1] ?? '') === '--child') {
    $token = (string) $argv[2];
    $action = (string) $argv[3];
    $scannerId = (int) $argv[4];
    $startAt = (float) $argv[5];

    $pdo = getDBConnection();
    $pdo->query('SELECT 1');                       // connect BEFORE the barrier
    while (microtime(true) < $startAt) {
        usleep(100);
    }
    echo performScanAction($pdo, $token, $action, $scannerId)['code'];
    exit(0);
}

// ---------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------
function check(string $name, bool $ok, string $detail = ''): void
{
    $GLOBALS['__counts'][$ok ? 'pass' : 'fail']++;
    echo ($ok ? '  PASS  ' : '  FAIL  ') . $name . ($ok || $detail === '' ? '' : "   -> $detail") . "\n";
}

function cleanup(PDO $pdo): void
{
    $pdo->exec("DELETE t FROM access_transactions t JOIN students s ON s.id = t.student_id WHERE s.student_id LIKE 'ZZTEST-%'");
    $pdo->exec("DELETE q FROM qr_credentials q JOIN students s ON s.id = q.student_id WHERE s.student_id LIKE 'ZZTEST-%'");
    $pdo->exec("DELETE FROM students WHERE student_id LIKE 'ZZTEST-%'");
    $pdo->exec("DELETE FROM users WHERE username LIKE 'zzscantest%'");
}

function makeUser(PDO $pdo, string $username, string $role): int
{
    $pdo->prepare("INSERT INTO users (username, password_hash, role, status) VALUES (?, '!', ?, 'ACTIVE')")
        ->execute([$username, $role]);
    return (int) $pdo->lastInsertId();
}

function makeStudent(PDO $pdo, string $tag, string $accountStatus = 'ACTIVE', string $current = 'OUT'): int
{
    $userId = makeUser($pdo, 'zzscantest_' . strtolower($tag), 'STUDENT');
    $pdo->prepare(
        "INSERT INTO students (user_id, student_id, first_name, last_name, course, year_level, status, current_status)
         VALUES (?, ?, 'Test', ?, 'BSIT', '1st Year', ?, ?)"
    )->execute([$userId, 'ZZTEST-' . $tag, 'Student' . $tag, $accountStatus, $current]);
    return (int) $pdo->lastInsertId();
}

function studentStatus(PDO $pdo, int $sid): string
{
    $s = $pdo->prepare('SELECT current_status FROM students WHERE id = ?');
    $s->execute([$sid]);
    return (string) $s->fetchColumn();
}

function txnCount(PDO $pdo, int $sid): int
{
    $s = $pdo->prepare('SELECT COUNT(*) FROM access_transactions WHERE student_id = ?');
    $s->execute([$sid]);
    return (int) $s->fetchColumn();
}

/** Fires one child process per action, all released at the same instant. */
function runConcurrent(string $token, array $actions, int $scannerId): array
{
    $startAt = sprintf('%.4f', microtime(true) + 2.0);
    $running = [];
    foreach ($actions as $action) {
        $cmd = [PHP_BINARY, __FILE__, '--child', $token, $action, (string) $scannerId, $startAt];
        $proc = proc_open($cmd, [1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes);
        $running[] = [$proc, $pipes];
    }
    $codes = [];
    foreach ($running as [$proc, $pipes]) {
        $codes[] = trim((string) stream_get_contents($pipes[1]));
        fclose($pipes[1]);
        fclose($pipes[2]);
        proc_close($proc);
    }
    return $codes;
}

// ---------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------
$GLOBALS['__counts'] = ['pass' => 0, 'fail' => 0];
$pdo = getDBConnection();
cleanup($pdo);

try {
    $scanner = makeUser($pdo, 'zzscantest_scanner', 'SCANNER');

    echo "\n== Tests 1-6: action vs. status, camera-style and manual-style tokens ==\n";
    $s = makeStudent($pdo, 'A');                       // starts OUT
    $token = createQrCredential($pdo, $s)['raw_token'];

    $r = performScanAction($pdo, $token, 'IN', $scanner);
    check('T1  OUT + select IN  -> SUCCESS_IN, status IN, 1 transaction',
        $r['code'] === 'SUCCESS_IN' && $r['ok'] === true && studentStatus($pdo, $s) === 'IN' && txnCount($pdo, $s) === 1,
        json_encode($r));

    $r = performScanAction($pdo, $token, 'IN', $scanner);
    check('T2  IN  + select IN  -> REJECTED "already IN", no new transaction, status unchanged',
        $r['code'] === 'ALREADY_IN' && $r['ok'] === false && studentStatus($pdo, $s) === 'IN' && txnCount($pdo, $s) === 1
        && str_contains($r['message'], 'is already IN.'), json_encode($r));

    $r = performScanAction($pdo, $token, 'OUT', $scanner);
    check('T3  IN  + select OUT -> SUCCESS_OUT, status OUT, 2 transactions',
        $r['code'] === 'SUCCESS_OUT' && studentStatus($pdo, $s) === 'OUT' && txnCount($pdo, $s) === 2, json_encode($r));

    $r = performScanAction($pdo, $token, 'OUT', $scanner);
    check('T4  OUT + select OUT -> REJECTED "already OUT", no new transaction, status unchanged',
        $r['code'] === 'ALREADY_OUT' && $r['ok'] === false && studentStatus($pdo, $s) === 'OUT' && txnCount($pdo, $s) === 2
        && str_contains($r['message'], 'is already OUT.'), json_encode($r));

    // "Manual entry": same function, token typed with stray spaces / capitals.
    $typed = '  ' . strtoupper($token) . ' ';
    $r = performScanAction($pdo, $typed, 'IN', $scanner);
    check('T5  manual token (padded, upper-case) + select IN  -> SUCCESS_IN',
        $r['code'] === 'SUCCESS_IN' && studentStatus($pdo, $s) === 'IN', json_encode($r));
    $r = performScanAction($pdo, $typed, 'OUT', $scanner);
    check('T6  manual token (padded, upper-case) + select OUT -> SUCCESS_OUT',
        $r['code'] === 'SUCCESS_OUT' && studentStatus($pdo, $s) === 'OUT' && txnCount($pdo, $s) === 4, json_encode($r));

    echo "\n== Test 7: missing / invalid action is blocked server-side ==\n";
    $before = [studentStatus($pdo, $s), txnCount($pdo, $s)];
    foreach ([null, '', 'in', 'TOGGLE', 'IN ', 'BOTH', 'OUT;DROP'] as $bad) {
        $r = performScanAction($pdo, $token, $bad, $scanner);
        check('T7  action ' . var_export($bad, true) . ' -> INVALID_ACTION, nothing written',
            $r['code'] === 'INVALID_ACTION' && [studentStatus($pdo, $s), txnCount($pdo, $s)] === $before, json_encode($r));
    }

    echo "\n== Tests 8-11: token and student checks ==\n";
    foreach ([bin2hex(random_bytes(32)), 'not-a-token', ''] as $bad) {
        $r = performScanAction($pdo, $bad, 'IN', $scanner);
        check('T8  invalid token ' . var_export(substr($bad, 0, 12), true) . ' -> TOKEN_INVALID, no student info',
            $r['code'] === 'TOKEN_INVALID' && !isset($r['student']), json_encode($r));
    }

    $s2 = makeStudent($pdo, 'B');
    [$raw, $hash] = generateQrToken();
    $pdo->prepare("INSERT INTO qr_credentials (student_id, token_hash, created_at, expires_at, status)
                   VALUES (?, ?, DATE_SUB(NOW(), INTERVAL 10 MINUTE), DATE_SUB(NOW(), INTERVAL 5 MINUTE), 'ACTIVE')")
        ->execute([$s2, $hash]);
    $r = performScanAction($pdo, $raw, 'IN', $scanner);
    check('T9  expired token -> TOKEN_EXPIRED, nothing written',
        $r['code'] === 'TOKEN_EXPIRED' && studentStatus($pdo, $s2) === 'OUT' && txnCount($pdo, $s2) === 0 && !isset($r['student']), json_encode($r));

    $cred = createQrCredential($pdo, $s2);
    revokeQrCredential($pdo, $cred['id']);
    $r = performScanAction($pdo, $cred['raw_token'], 'IN', $scanner);
    check('T10 revoked token -> TOKEN_REVOKED, nothing written',
        $r['code'] === 'TOKEN_REVOKED' && studentStatus($pdo, $s2) === 'OUT' && txnCount($pdo, $s2) === 0 && !isset($r['student']), json_encode($r));

    $s3 = makeStudent($pdo, 'C', 'INACTIVE');
    $inactiveToken = createQrCredential($pdo, $s3)['raw_token'];
    $r = performScanAction($pdo, $inactiveToken, 'IN', $scanner);
    check('T11 inactive student -> STUDENT_INACTIVE, nothing written, no student info',
        $r['code'] === 'STUDENT_INACTIVE' && studentStatus($pdo, $s3) === 'OUT' && txnCount($pdo, $s3) === 0 && !isset($r['student']), json_encode($r));

    echo "\n== Test 12: simultaneous scans of the same student (8 parallel processes) ==\n";
    $s4 = makeStudent($pdo, 'D');                      // OUT
    $tok4 = createQrCredential($pdo, $s4)['raw_token'];

    $codes = runConcurrent($tok4, array_fill(0, 8, 'IN'), $scanner);
    $ok = count(array_keys($codes, 'SUCCESS_IN')) === 1 && count(array_keys($codes, 'ALREADY_IN')) === 7;
    check('T12a 8 x IN from OUT -> exactly 1 SUCCESS_IN, 7 ALREADY_IN, 1 transaction, status IN',
        $ok && txnCount($pdo, $s4) === 1 && studentStatus($pdo, $s4) === 'IN', implode(',', $codes));

    $codes = runConcurrent($tok4, array_fill(0, 8, 'OUT'), $scanner);
    $ok = count(array_keys($codes, 'SUCCESS_OUT')) === 1 && count(array_keys($codes, 'ALREADY_OUT')) === 7;
    check('T12b 8 x OUT from IN -> exactly 1 SUCCESS_OUT, 7 ALREADY_OUT, 2 transactions, status OUT',
        $ok && txnCount($pdo, $s4) === 2 && studentStatus($pdo, $s4) === 'OUT', implode(',', $codes));

    $s5 = makeStudent($pdo, 'E');                      // OUT
    $tok5 = createQrCredential($pdo, $s5)['raw_token'];
    $codes = runConcurrent($tok5, ['IN', 'OUT', 'IN', 'OUT', 'IN', 'OUT', 'IN', 'OUT'], $scanner);
    $rows = $pdo->prepare('SELECT transaction_type FROM access_transactions WHERE student_id = ? ORDER BY id');
    $rows->execute([$s5]);
    $types = $rows->fetchAll(PDO::FETCH_COLUMN);
    $alternates = true;
    foreach ($types as $i => $type) {
        $expected = $i % 2 === 0 ? 'IN' : 'OUT';      // started OUT, so the log must go IN, OUT, IN, ...
        if ($type !== $expected) { $alternates = false; }
    }
    $successes = count($codes) - count(array_keys($codes, 'ALREADY_IN')) - count(array_keys($codes, 'ALREADY_OUT'));
    $last = $types ? end($types) : 'OUT';
    check('T12c 4 IN + 4 OUT mixed -> log strictly alternates IN,OUT,..., #rows == #successes, status == last row',
        $alternates && count($types) === $successes && studentStatus($pdo, $s5) === $last,
        'codes=' . implode(',', $codes) . ' log=' . implode(',', $types));
} finally {
    cleanup($pdo);
}

$counts = $GLOBALS['__counts'];
echo "\nResult: {$counts['pass']} passed, {$counts['fail']} failed.\n";
exit($counts['fail'] === 0 ? 0 : 1);
