<?php
declare(strict_types=1);

/**
 * ONE-OFF UTILITY - NOT part of the application.
 *
 * Run this from the command line to generate a bcrypt hash for a new
 * admin (or any user) account. The password is read interactively so it
 * is never typed into a file, never left in shell history, and never
 * hard-coded anywhere.
 *
 * Usage (from a terminal, inside XAMPP's php.exe or any PHP 7.2+ CLI):
 *   php tools/generate_password_hash.php
 *
 * Do NOT commit this file's output, and do NOT add a plaintext password
 * as a hard-coded default in this script. Delete or keep this file out
 * of any public/deployed copy of the project once you're done with it.
 */

if (PHP_SAPI !== 'cli') {
    die('This script must be run from the command line, not a web browser.');
}

// Hide input where the terminal supports it (Linux/macOS). On native
// Windows CMD this will just echo the password -- run via WSL/Git Bash
// if you want it hidden there too.
function readHiddenInput(string $prompt): string
{
    echo $prompt;
    if (stripos(PHP_OS, 'WIN') === 0) {
        return trim((string) fgets(STDIN));
    }
    system('stty -echo');
    $input = trim((string) fgets(STDIN));
    system('stty echo');
    echo "\n";
    return $input;
}

$password = readHiddenInput('Enter password to hash: ');
$confirm  = readHiddenInput('Confirm password: ');

if ($password === '') {
    die("Password cannot be empty.\n");
}

if ($password !== $confirm) {
    die("Passwords did not match. Run the script again.\n");
}

$hash = password_hash($password, PASSWORD_BCRYPT);

echo "\nBcrypt hash (copy this into the database, not the password):\n";
echo $hash . "\n";

// Immediately drop the plaintext password from memory.
$password = $confirm = '';
unset($password, $confirm);
