# Digital Identification System for Student Access Verification

**Project:** Design and Development of a Digital Identification System for
Student Access Verification at Our Lady of Lourdes College

> **UI update:** the interface has been modernized (shared design system, responsive
> sidebar layout, confirmation dialogs, accessible forms) without changing the
> backend workflow. Two backend bugs were also fixed (QR expiry time-zone mismatch;
> search pages crashing). See `UI-MODERNIZATION-REPORT.md` for details, test results
> and the items still to verify on your own XAMPP setup.

## Technology

- HTML5
- CSS3
- JavaScript
- PHP
- MySQL
- Apache/XAMPP

## Main Roles

- **ADMIN** — student management, QR credential management, access monitoring/dashboard
- **STUDENT** — own profile, own temporary QR generation
- **SCANNER** — QR verification, access transaction processing

## Main Features

- Student management (add/edit/activate/deactivate)
- Temporary QR generation (cryptographically random, opaque token; no personal data encoded)
- QR verification (server-side only; expiration/revocation enforced)
- Student IN/OUT access tracking (atomic, concurrency-safe state transitions)
- Access transaction logging
- Admin dashboard
- Access monitoring (search, filter, pagination)
- Role-based access control (server-side, not link-hiding)
- CSRF protection on all state-changing requests
- Prepared SQL statements throughout (no raw query concatenation)
- Password hashing (bcrypt via `password_hash()`/`password_verify()`)
- Secure temporary QR tokens (256-bit random, only SHA-256 hash stored)

## Local Installation

1. Install XAMPP.
2. Start Apache and MySQL.
3. Copy this project folder into your XAMPP `htdocs` directory (any
   subfolder name works — the app auto-detects its own base path, so it
   doesn't need to sit at the web server root).
4. Create the database and import the schema: run `database/schema.sql` in
   phpMyAdmin or the `mysql` CLI. This creates the `digital_id_system`
   database, all tables, and a placeholder `admin` account row.
5. Import `database/schema.sql` (same step as above if not already done).
6. Check `config/database.php` and adjust the host/username/password if your
   local MySQL setup differs from the default XAMPP `root` with no password.
7. Open the project through `http://localhost/<project-folder>/`.
8. Generate/prepare the required user accounts:
   - The `admin` row created by `schema.sql` has a placeholder password hash
     that will not authenticate anything. Generate a real one yourself with
     `tools/generate_password_hash.php` (run from the command line only —
     it will not run over HTTP), then apply it with an `UPDATE users SET
     password_hash = '<your generated hash>' WHERE username = 'admin';`
     statement.
   - Create STUDENT and SCANNER accounts through the admin interface
     (`admin/student-add.php` for students; scanner/other staff accounts can
     be added directly in the `users` table until an admin "manage
     accounts" UI is built).
9. **Live testing status:** this project has been reviewed through static
   code analysis, control-flow/logic verification, and algorithm-level
   simulation, but has not yet been executed against a real PHP/MySQL/Apache
   server. Please run through authentication, RBAC, QR generation/scanning,
   IN/OUT transitions, the concurrent-scan test (`tools/concurrent-scan-test.md`),
   and the admin dashboard/access logs on your own XAMPP environment before
   relying on this system for real use.

## Notes

- `tools/generate_password_hash.php` is CLI-only by design (refuses to run
  over HTTP) and is additionally blocked from direct web access via
  `tools/.htaccess`. Confirm your Apache `AllowOverride` setting actually
  honors `.htaccess` files in your environment — see
  `tools/concurrent-scan-test.md` and the project's security review notes
  for details on this and other checks still requiring a live environment.
- No real credentials, raw QR tokens, or user-specific token hashes are
  included anywhere in this package.
- `assets/js/qrcode.min.js` (QR rendering) and `assets/js/qrscanner.min.js`
  (camera-based QR scanning) are both included locally — no CDN, works
  offline. See the `README-*.txt` files alongside them in `assets/js/` for
  exactly how each was built/verified and what still needs a real-device
  check (a physical phone scan of a rendered code; camera scanning on your
  actual target browsers).

## Quick Test Logins (development only)

After importing `database/schema.sql`, import `database/seed_test_accounts.sql`
(or run `php tools/seed_test_accounts.php`). Then log in at `/auth/login.php`:

| Role    | Username            | Password   |
| ------- | ------------------- | ---------- |
| Admin   | admin@gmail.com     | admin123   |
| Student | student@gmail.com   | student123 |
| Scanner | scanner@gmail.com   | scanner123 |

Delete these accounts before any real deployment.

## Scanner workflow (select action first)

1. Log in as a SCANNER user. The page first asks **Select Access Action**:
   **SCAN IN** (student entering) or **SCAN OUT** (student leaving). The camera
   does not start until one is chosen.
2. The chosen action is shown as a badge with a **Change Action** button.
   Scan the student's QR with the camera, or paste/type the **token** (the
   student can copy it from *Generate Temporary QR* -> "Token for manual
   entry") and press **Verify & Record**.
3. The browser sends `action` + `token` (+ CSRF token) to `scanner/verify.php`.
   The server re-validates everything: role, CSRF, action, token (exists, not
   expired, not revoked), student active, and the student's current status.
4. IN is only accepted when the student is OUT; OUT only when the student is
   IN. Otherwise the request is rejected ("already IN" / "already OUT") and
   nothing is written. There is no automatic toggling.

Backend test (needs MySQL + schema): `php tools/test-scanner-actions.php`.
