<?php
declare(strict_types=1);

/**
 * Returns a shared PDO connection to the digital_id_system database.
 * Adjust credentials below to match your XAMPP MySQL setup.
 */
function getDBConnection(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $host    = 'localhost';
        $db      = 'digital_id_system';
        $user    = 'root';
        $pass    = '';
        $charset = 'utf8mb4';

        $dsn = "mysql:host={$host};dbname={$db};charset={$charset}";

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            $pdo = new PDO($dsn, $user, $pass, $options);
        } catch (PDOException $e) {
            // Never expose raw DB errors to the user.
            error_log('DB connection failed: ' . $e->getMessage());
            http_response_code(500);
            die('A system error occurred. Please try again later.');
        }
    }

    return $pdo;
}
