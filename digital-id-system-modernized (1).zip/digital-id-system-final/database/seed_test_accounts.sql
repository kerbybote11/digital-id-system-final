-- =====================================================================
-- DEV/TEST SEED: simple login accounts for every role.
-- Run AFTER database/schema.sql. Safe to re-run (idempotent).
-- DEVELOPMENT ONLY -- delete these accounts before any real deployment.
-- Passwords are stored as bcrypt ($2y$, cost 10), the same format used by
-- PHP password_hash(PASSWORD_BCRYPT) and checked by password_verify().
--
--   admin@gmail.com    / admin123    (ADMIN)
--   student@gmail.com  / student123  (STUDENT)
--   scanner@gmail.com  / scanner123  (SCANNER)
-- =====================================================================
USE digital_id_system;

INSERT INTO users (username, password_hash, role, status) VALUES
  ('admin@gmail.com',   '$2y$10$RFX9G7QGE2RHZ4bnTFNoG.UsCeIAzSav59f8fsasOkW.VgqDtPupy',   'ADMIN',   'ACTIVE'),
  ('student@gmail.com', '$2y$10$Y0XCLiT8BAMcYJH9PYA1NOBaaLq6zLKhaPD0vaLWMC0/7.DcdzO8K', 'STUDENT', 'ACTIVE'),
  ('scanner@gmail.com', '$2y$10$utd7iL/Xw2texh0JD5MVrOMTJRIu0U3iFnSIR4AUcfBwyeX3FLa4.', 'SCANNER', 'ACTIVE')
ON DUPLICATE KEY UPDATE
  password_hash = VALUES(password_hash),
  role          = VALUES(role),
  status        = 'ACTIVE';

-- Student profile (required by student/dashboard.php and generate-qr.php)
INSERT INTO students (user_id, student_id, first_name, last_name, course, year_level, status, current_status)
SELECT u.id, 'TEST-0001', 'Test', 'Student', 'BS Information Technology', '3rd Year', 'ACTIVE', 'OUT'
FROM users u
WHERE u.username = 'student@gmail.com'
ON DUPLICATE KEY UPDATE
  first_name = VALUES(first_name), last_name = VALUES(last_name),
  course = VALUES(course), year_level = VALUES(year_level),
  status = 'ACTIVE', current_status = 'OUT';
