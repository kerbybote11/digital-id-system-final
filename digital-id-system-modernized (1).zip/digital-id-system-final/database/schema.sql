-- Digital Identification System -- approved Phase 2 schema.
-- Persisted here for repository completeness during the Phase 9 security
-- review; content is unchanged from what was approved in Phase 2.

CREATE DATABASE IF NOT EXISTS digital_id_system
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE digital_id_system;

-- ============================
-- USERS (authentication + role)
-- ============================
CREATE TABLE users (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(50)  NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    role            ENUM('ADMIN','SCANNER','STUDENT') NOT NULL,
    status          ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================
-- STUDENTS (profile + live IN/OUT status)
-- ============================
CREATE TABLE students (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id         INT UNSIGNED NOT NULL UNIQUE,
    student_id      VARCHAR(30)  NOT NULL UNIQUE,
    first_name      VARCHAR(100) NOT NULL,
    last_name       VARCHAR(100) NOT NULL,
    course          VARCHAR(100) NOT NULL,
    year_level      VARCHAR(20)  NOT NULL,
    status          ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    current_status  ENUM('IN','OUT') NOT NULL DEFAULT 'OUT',
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_students_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE INDEX idx_students_status ON students(status);

-- ============================
-- QR CREDENTIALS (temporary tokens)
-- ============================
CREATE TABLE qr_credentials (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id      INT UNSIGNED NOT NULL,
    token_hash      CHAR(64) NOT NULL UNIQUE,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at      DATETIME NOT NULL,
    status          ENUM('ACTIVE','EXPIRED','REVOKED','USED') NOT NULL DEFAULT 'ACTIVE',
    revoked_at      DATETIME NULL,
    CONSTRAINT fk_qr_student
        FOREIGN KEY (student_id) REFERENCES students(id)
        ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE INDEX idx_qr_student ON qr_credentials(student_id);
CREATE INDEX idx_qr_status_expiry ON qr_credentials(status, expires_at);

-- ============================
-- ACCESS TRANSACTIONS (IN/OUT log)
-- ============================
CREATE TABLE access_transactions (
    id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id          INT UNSIGNED NOT NULL,
    qr_credential_id    INT UNSIGNED NULL,
    transaction_type    ENUM('IN','OUT') NOT NULL,
    timestamp           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    scanner_user_id     INT UNSIGNED NOT NULL,
    verification_result ENUM('SUCCESS','REJECTED_EXPIRED','REJECTED_REVOKED',
                              'REJECTED_UNKNOWN','REJECTED_STATE','REJECTED_INACTIVE') NOT NULL,
    CONSTRAINT fk_txn_student
        FOREIGN KEY (student_id) REFERENCES students(id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_txn_qr
        FOREIGN KEY (qr_credential_id) REFERENCES qr_credentials(id)
        ON DELETE SET NULL,
    CONSTRAINT fk_txn_scanner
        FOREIGN KEY (scanner_user_id) REFERENCES users(id)
        ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE INDEX idx_txn_student ON access_transactions(student_id);
CREATE INDEX idx_txn_timestamp ON access_transactions(timestamp);
CREATE INDEX idx_txn_type ON access_transactions(transaction_type);

-- ============================
-- SYSTEM CONFIG (admin-configurable settings)
-- ============================
CREATE TABLE system_config (
    config_key      VARCHAR(50) PRIMARY KEY,
    config_value    VARCHAR(255) NOT NULL,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO system_config (config_key, config_value)
VALUES ('qr_expiry_minutes', '5');

-- ============================
-- SEED ADMIN ACCOUNT
-- Placeholder hash only -- it will not authenticate anything. Generate a
-- real one yourself with tools/generate_password_hash.php (CLI-only), then
-- apply it directly with:
--   UPDATE users SET password_hash = '<your generated hash>' WHERE username = 'admin';
-- Do not use this placeholder value as a real credential.
-- ============================
INSERT INTO users (username, password_hash, role, status)
VALUES ('admin', '$2y$10$replaceThisWithARealBcryptHashGeneratedByPHP', 'ADMIN', 'ACTIVE');
