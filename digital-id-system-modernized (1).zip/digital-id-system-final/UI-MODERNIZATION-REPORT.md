# UI/UX Modernization Report

This report covers the redesign of the existing Digital ID System's user interface. The PHP/MySQL backend, database schema, authentication, role checks, CSRF protection, QR security model and the IN/OUT transition logic were kept. The only backend edits are two bug fixes, described in section 4.

The workflow is unchanged: **ADMIN** manages students and QR credentials → **STUDENT** generates a temporary QR → **SCANNER** verifies it → the system records the IN/OUT status and logs it.

---

## 1. What changed in the UI

### Design system (`assets/css/style.css`, rewritten)
- **Tokens:** all colours, spacing, radii, shadows and type sizes are CSS variables on `:root`. The palette is blue (primary) with slate neutrals.
- **Semantic colours:** success, warning and danger each have a colour. IN is green and OUT is amber. A badge always shows text next to its colour dot, so colour is never the only signal.
- **Fonts:** a system font stack is used, so no web-font download is needed and the app works offline on XAMPP.
- **Components:**
  - buttons: primary, secondary, outline, danger, danger-outline, success-outline and ghost, in small, large, block and icon sizes, with a loading spinner
  - form controls: inputs with icons, password toggle, hints and inline errors
  - cards, stat cards, data tables, pagination, badges, alerts, empty states, the confirmation dialog, the sidebar and top bar, the QR panel and the scanner panels
- **Responsive layout:**
  - The sidebar becomes an off-canvas drawer below 1024px.
  - Tables become labelled cards below 720px.
  - Forms drop to a single column on phones.
  - The camera area adapts to landscape.
  - Touch targets are at least 44px.
- **Accessibility:**
  - skip link
  - visible focus rings
  - `aria-current` on the active nav item
  - accessible names on icon-only buttons
  - `aria-invalid` and `aria-describedby` on form errors
  - live regions for results and QR expiry
  - `prefers-reduced-motion` support
  - print styles

### Shared layout (`includes/layout.php`, new)
- Contains `renderPageStart()` and `renderPageEnd()`, which output the head, sidebar (per role), top bar with account menu, footer and the shared confirmation dialog.
- Contains helpers:
  - `e()` for escaping
  - `icon()` for inline SVG icons
  - badge helpers: `accessBadge()`, `accountStatusBadge()`, `qrStatusBadge()`
  - `timeCell()` and `formatDateTime()`
  - `renderAlert()` and `renderEmptyState()`
  - `formField()` and `mapStudentFormErrors()`
- It is presentation only. Every page still calls `requireRole()` itself, so navigation is never the security boundary.

### Shared behaviour (`assets/js/app.js`, new)
- Opens and closes the mobile drawer (Esc closes it and focus is restored), and closes the account menu on an outside click or Esc.
- Dismissible alerts.
- Shows a confirmation `<dialog>` before any form marked `data-confirm` is submitted, falling back to `window.confirm` in older browsers.
- Password show/hide toggle. The button stays hidden when JavaScript is off, so there is never a control that does nothing.
- Puts submit buttons into a loading/disabled state, which prevents double-submission.

### Pages
| Page | Changes |
|---|---|
| Login | Split layout: brand panel and form on desktop, a single card on mobile. Icon inputs, built-in password toggle, loading state. Errors use the existing generic messages, so they don't reveal whether a username exists. |
| Admin dashboard | Four stat cards showing all seven existing database counts. Recent-activity table with IN/OUT badges, quick-action links and an empty state. |
| Students | Labelled search and status filter, clear-filters link, result count and status badges. Edit, Deactivate and Activate buttons, with a **confirmation dialog** for status changes. **Success messages for add, update and status change**: the original redirected with `?added=1`, `?updated=1` and `?status_updated=1` but never displayed them. Distinct empty states for "no students" and "no match". |
| Add / Edit student | Grouped sections and two-column grid. Server validation errors appear inline under the matching field as well as in a summary. Hints, required markers, `maxlength`/`minlength` matching the server rules, and a year-level suggestion list (still free text). The edit page has an account and access side panel and its own confirmed activate/deactivate action. |
| QR credentials | Status badges for Active, Expired, Revoked and Used, plus the revoked-at time. **Confirmation before revoking.** Search, empty states, and a note that the list shows up to the 200 most recent credentials (an existing query limit). |
| Access logs | Filter bar (search, IN/OUT, date range), result count with "Showing x–y", IN/OUT badges, two-line timestamps, and numbered pagination that keeps the filters. Empty and no-match states. Records are read-only. |
| Student dashboard | Welcome banner with real student data and the main QR action. Current access status tile, current QR status tile, details, and a static "how it works" section. A warning appears if the account is inactive. |
| My Digital ID | Visual ID card plus a profile details list. The backend has no student edit endpoint, so the page has no edit controls; a note explains that corrections go through an administrator. |
| Temporary QR | Large QR panel, mm:ss countdown with a progress bar, and an expired overlay. The status badge changes to Expired and a screen-reader announcement plays at expiry. The manual-entry token is folded inside "Camera not working?" so it isn't shown by default. There is a regenerate card and safety guidance. Separate states for no QR, expired, revoked, and a QR created in another session. |
| Scanner | Step indicator that highlights the current step. Large touch-friendly SCAN IN and SCAN OUT buttons, the selected-action badge, and a larger camera area with an aiming frame. Camera help notes, a **"Try camera again"** button (shown only when a retry could help), and manual token entry. The result panel gained a **reason label** (Entry recorded, Already inside, QR expired, QR revoked, QR not recognised, Inactive account, and others) so outcomes with the same title look different at a glance. |

Inline `<script>` blocks were moved out of `student/generate-qr.php` into `assets/js/student-qr.js`, with the same behaviour.

---

## 2. Files

**Added**
- `includes/layout.php` (shared layout and view helpers)
- `assets/js/app.js` (shared UI behaviour)
- `assets/js/student-qr.js` (QR rendering and copy button, moved from inline)
- `UI-MODERNIZATION-REPORT.md` (this file)

**Modified**
- `assets/css/style.css`: rewritten design system. Class names used by `scanner.js` were kept.
- `auth/login.php`: markup only. The login logic above the HTML is unchanged.
- `admin/dashboard.php`, `admin/access-logs.php`, `admin/student-add.php`, `admin/student-edit.php`: markup only.
- `admin/students.php`: markup, plus fix B.
- `admin/qr-management.php`: markup, plus fixes A and B.
- `student/dashboard.php`: markup. The SELECT now also reads `id` so it can show QR status.
- `student/profile.php`: markup only.
- `student/generate-qr.php`: markup. The countdown now uses values computed by MySQL.
- `scanner/scanner.php`: markup in the shared shell. All element IDs used by `scanner.js` were kept.
- `assets/js/scanner.js`: small additions only (camera retry button, reason label). The workflow, state machine, CSRF handling and double-submit guard are unchanged.
- `assets/js/qr-countdown.js`: uses server-computed seconds and updates the panel on expiry. It is still cosmetic only.
- `includes/qr.php`: fix A.
- `includes/reports.php`: fix B.

- `includes/session.php`: more robust base-folder detection, so CSS and JS links also work under Apache Alias, nested folders and Windows path-case differences. Adds `asset()`, which appends `?v=<file time>` to CSS and JS links so browsers never keep a stale cached stylesheet.

**Not changed:** `config/database.php`, `includes/csrf.php`, `includes/access.php`, `includes/validation.php`, `admin/student-toggle-status.php`, `scanner/verify.php`, `auth/logout.php`, `index.php`, `database/*`, `tools/*`, `assets/js/qrcode.min.js`, `assets/js/qrscanner.min.js`.

---

## 3. Backend features kept
- Login with bcrypt `password_verify`, generic error messages, inactive-account check, `session_regenerate_id`, and role-based redirects.
- Server-side role checks (`requireRole` / `requireRoleJson`) on every page and endpoint.
- CSRF tokens on every state-changing form and on `verify.php`.
- Prepared statements throughout.
- Student add (user and student rows created in one transaction), edit, and activate/deactivate (student and user status changed together).
- QR tokens: 256-bit random, only the SHA-256 hash is stored, one active QR per student (rotation), lazy expiry, admin revocation, and the raw token kept only in the session.
- Scanner: the operator picks the action, the server re-validates everything, the student row is locked with `SELECT … FOR UPDATE`, IN is accepted only when the student is OUT and OUT only when IN, and no outcome includes personal data except a valid scan.
- Access logs and dashboard queries are read-only.

---

## 4. Bugs found and fixed (minimal backend corrections)

**A. Expired QR codes could be accepted (time-zone mismatch).**
- *Cause:* `includes/qr.php` compared `strtotime($expires_at) < time()`. But `expires_at` is written with MySQL's `NOW()`, which uses the database time zone, while `strtotime()` reads the string in PHP's `date.timezone`. XAMPP's `php.ini` ships with `date.timezone=Europe/Berlin`, while MySQL uses the PC's own time zone (for example Asia/Manila). Whenever PHP's zone is behind MySQL's, an expired token is treated as valid for the difference in hours.
- *Reproduced:* with the project's own `tools/test-scanner-actions.php` and PHP set behind the database clock, the original code returned `SUCCESS_IN` for an expired token (test T9 failed).
- *Fix:* MySQL now does the comparison with `(expires_at < NOW()) AS is_past_expiry`, in `getCurrentQrForStudent()`, `validateQrTokenForScan()` and the QR management list. Statuses, expiry length, revocation and rotation work the same. After the fix, T9 passes under the same mismatch.

**B. Every search box crashed with "A system error occurred".**
- *Cause:* `admin/students.php`, `admin/qr-management.php` and `includes/reports.php` (access logs) reused one named placeholder (`:search`) several times in a query. With `PDO::ATTR_EMULATE_PREPARES => false`, as set in `config/database.php`, PDO MySQL rejects this with `SQLSTATE[HY093] Invalid parameter number`.
- *Reproduced:* against the original code, all three pages returned HTTP 500 for any search term.
- *Fix:* distinct placeholders (`:search1`, `:search2`, …) bound to the same value. The query meaning is unchanged.

---

## 5. Testing performed

**Environment used:** PHP 8.4 built-in server, with the project installed in a sub-folder to exercise the `BASE_URL` auto-detection. MySQL was not available, so the database was **Dolt 2.4**, a MySQL-compatible server. `database/schema.sql` was imported and accounts were seeded with `tools/seed_test_accounts.php`. Browser tests ran in headless Chromium through Playwright.

**Static checks**
- `php -l` on all 26 PHP files: no syntax errors.
- `node --check` on all 6 JS files: OK.
- All asset paths, form actions and links resolve under the sub-folder install. No 404s in the server log.
- No PHP warnings, notices or uncaught exceptions after fix B.
- No browser console errors on any page.

**Automated browser tests: 83 of 83 passed**
- Login: valid and invalid, generic error for an unknown user, username kept after an error, password toggle.
- Role redirects for all three roles. A logged-out request to a protected page redirects to login.
- Students:
  - add: server validation shown inline, duplicate Student ID error, password not echoed back, rows created
  - search, filter, empty states
  - edit: save and validation
  - status change through the confirmation dialog: Cancel, Esc and Confirm all work. An inactive account can't log in. Reactivation works.
- QR: the rendered QR was **decoded with OpenCV and matched the server token**. Only the SHA-256 hash is stored. The countdown displays, and a simulated clock fast-forward flips the panel to the expired state.
- Scanner, using manual token entry:
  - SCAN IN succeeds; a second SCAN IN gives "Already inside"; SCAN OUT succeeds
  - an invalid token gives an error with no student data
  - after an admin revokes, the token gives "QR revoked"; an expired token gives "QR expired"; a deactivated student gives "Inactive account"
  - the database status and transaction rows were checked after each step
- 22 alternating IN/OUT requests through `verify.php` all succeeded. A bad CSRF token is rejected with 403.
- Access logs: the count matches the database, pagination keeps the filters, the IN/OUT filter works, and an empty date range shows the empty state.
- Role restrictions:
  - a student gets 403 on the admin pages, the scanner page, `verify.php` (JSON 403) and toggle-status
  - a scanner gets 403 on the admin and student pages
- Logout, then a protected page redirects to login, then logging back in works.
- Mobile drawer opens and closes (including Esc), and its links navigate.
- No horizontal scrolling on any page at 375, 768, 1024 or 1280px wide (page screenshots were reviewed).

**Project backend test (`php tools/test-scanner-actions.php`):** 19 of 22 pass.
- T1–T11 all pass (action vs. status, invalid action, invalid, expired, revoked and inactive tokens).
- The 3 failures are T12a, T12b and T12c, the 8-process concurrency test. **This is a limitation of the test database, not of this code:** Dolt does not take row locks for `SELECT … FOR UPDATE`. The locking code was not touched. Re-run this test on real MySQL/MariaDB (XAMPP), where it is expected to pass.

**Not tested here; please check on your machine**
1. **The concurrency test on real MySQL:** `php tools/test-scanner-actions.php` should report 22 passed.
2. **Camera scanning on a real device:** open the scanner over HTTPS or `localhost` in Chrome or Edge on Android, choose SCAN IN, allow the camera, and scan a student's QR from another phone.
   - Expected: the result panel appears.
   - Also deny camera permission once to see the warning and the "Try camera again" button.
   - Headless Linux Chromium has no `BarcodeDetector`, so only the "not supported → enter manually" path could be checked here.
3. **Physically scanning the QR with a phone camera:** the rendered code decoded correctly in OpenCV, but a real phone camera was not available.
4. **The XAMPP time zones:** the fix makes expiry independent of them. Still, keeping `date.timezone` in `php.ini` equal to your PC's time zone (for example `Asia/Manila`) makes displayed times consistent.
5. **The visual check on a physical phone or tablet in portrait and landscape**, especially the scanner camera area.

---

## 6. Known issues and notes
- **Seed usernames vs. validation:** the seeded test accounts use email-style usernames (`admin@gmail.com`), but `validateUsernameFormat()` only allows letters, numbers and underscores. Accounts created through **Add student** therefore can't use email addresses. This was left unchanged because it is a validation-policy decision. Widen the regex in `includes/validation.php` if you want email usernames.
- `database/seed_test_accounts.sql` uses `INSERT … SELECT … ON DUPLICATE KEY UPDATE … VALUES()`, which MySQL/MariaDB accept but MySQL 8.0.20+ reports as deprecated. `tools/seed_test_accounts.php` does the same job.
- Error pages produced by `die()` (403 "Access denied", 404 "Student not found") are still plain text, as before.
- Every admin page that shows students now uses the same "Last, First" name format, the same badges and the same date format.

---

## 7. Running locally (XAMPP)

> **If the page looks unstyled:**
> - Open the app through Apache (`http://localhost/...`), not by double-clicking a `.php` file.
> - Press **Ctrl+F5** once to clear any old cached stylesheet.
> - Make sure you copied the **whole** folder, including `assets/`.

1. Install XAMPP and start **Apache** and **MySQL**.
2. Copy the `digital-id-system-final` folder into `C:\xampp\htdocs\`. Any sub-folder name works.
3. In phpMyAdmin, run `database/schema.sql`, then `database/seed_test_accounts.sql`. Or, from the project folder, run `C:\xampp\php\php.exe tools\seed_test_accounts.php`.
4. If your MySQL root user has a password, edit `config/database.php`.
5. Optional but recommended: in `C:\xampp\php\php.ini`, set `date.timezone=Asia/Manila` (or your zone), then restart Apache.
6. Open `http://localhost/digital-id-system-final/`.
7. Sign in with a test account. Delete these accounts before real use.
   - Admin: `admin@gmail.com` / `admin123`
   - Student: `student@gmail.com` / `student123`
   - Scanner: `scanner@gmail.com` / `scanner123`
8. Camera scanning from a phone needs HTTPS. `localhost` only counts as secure on the PC itself. Either enable Apache SSL in XAMPP, or use the manual token entry.
