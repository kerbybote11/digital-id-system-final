<?php
declare(strict_types=1);

/**
 * Scanner verification endpoint (JSON).
 *
 * Receives { csrf_token, action, qr_token } via POST from scanner/scanner.php.
 * Camera scans and manually typed tokens both arrive here and both go through
 * the exact same server-side function, performScanAction(). Nothing the
 * browser sends is trusted: the role, CSRF token, action, token and the
 * student's current status are all (re)validated on the server.
 */

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/qr.php';
require_once __DIR__ . '/../includes/access.php';
require_once __DIR__ . '/../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // Opening this URL directly (not via the scanner page) just goes back to it.
    header('Location: ' . url('/scanner/scanner.php'));
    exit;
}

requireRoleJson('SCANNER');

// Cast defensively: a crafted request could send an array instead of a string.
$csrf     = isset($_POST['csrf_token']) && is_string($_POST['csrf_token']) ? $_POST['csrf_token'] : null;
$rawToken = isset($_POST['qr_token'])   && is_string($_POST['qr_token'])   ? $_POST['qr_token']   : '';
$action   = isset($_POST['action'])     && is_string($_POST['action'])     ? $_POST['action']     : null;

if (!verifyCsrfToken($csrf)) {
    jsonResponse(403, [
        'ok' => false, 'code' => 'CSRF_INVALID', 'severity' => 'error',
        'title' => 'REQUEST REJECTED',
        'message' => 'Your session is out of date. Reload the scanner page and try again.',
    ]);
}

$pdo = getDBConnection();

jsonResponse(200, performScanAction($pdo, $rawToken, $action, (int) currentUserId()));
