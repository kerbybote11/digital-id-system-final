<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/layout.php';

requireRole('SCANNER');
?>
<?php renderPageStart('Access Scanner', [
    'active'   => 'scanner',
    'subtitle' => 'Verify student QR codes and record IN / OUT access',
]); ?>
<div class="scanner-shell" id="scanner-app"
     data-verify-url="<?= e(url('/scanner/verify.php')) ?>"
     data-csrf-token="<?= e(csrfToken()) ?>">

    <ol class="scanner-stepper" aria-label="Scanning steps">
        <li><span class="step-text">Choose IN or OUT</span><span class="sr-only">Step 1: choose IN or OUT</span></li>
        <li><span class="step-text">Scan or enter token</span><span class="sr-only">Step 2: scan or enter token</span></li>
        <li><span class="step-text">See the result</span><span class="sr-only">Step 3: see the result</span></li>
    </ol>

    <!-- STEP 1: choose the access action. The camera is NOT started here. -->
    <section class="scanner-card" id="step-action" aria-labelledby="action-heading">
        <span class="step-eyebrow">Step 1 of 3</span>
        <h2 id="action-heading">Select access action</h2>
        <p class="muted">Choose what you are recording before scanning. The camera starts after you choose.</p>
        <div class="action-grid">
            <button type="button" class="action-btn action-in" data-action="IN">
                <span class="action-icon"><?= icon('arrow-in') ?></span>
                <span class="action-text">
                    <span class="action-title">SCAN IN</span>
                    <span class="action-sub">Student entering campus</span>
                </span>
            </button>
            <button type="button" class="action-btn action-out" data-action="OUT">
                <span class="action-icon"><?= icon('arrow-out') ?></span>
                <span class="action-text">
                    <span class="action-title">SCAN OUT</span>
                    <span class="action-sub">Student leaving campus</span>
                </span>
            </button>
        </div>
    </section>

    <!-- STEP 2: scan or type a token. Hidden until an action is chosen. -->
    <section class="scanner-card" id="step-scan" aria-labelledby="scan-heading" hidden>
        <div class="selected-bar">
            <p class="selected-label">Selected action:
                <span class="badge" id="selected-action-badge">--</span>
            </p>
            <button type="button" class="secondary-btn" id="change-action"><?= icon('refresh', 'icon icon-sm') ?>Change action</button>
        </div>

        <span class="step-eyebrow">Step 2 of 3</span>
        <h2 id="scan-heading" tabindex="-1">Scan the student’s QR code</h2>
        <div class="camera-box" id="camera-box">
            <div id="camera-scan-area"></div>
        </div>
        <p class="camera-status" id="camera-status" role="status"></p>
        <div class="camera-tools">
            <button type="button" class="secondary-btn" id="camera-retry" hidden><?= icon('camera', 'icon icon-sm') ?>Try camera again</button>
        </div>

        <details class="help-details">
            <summary><?= icon('info', 'icon icon-sm') ?>Camera help</summary>
            <ul>
                <li>When your browser asks for camera permission, choose <strong>Allow</strong>.</li>
                <li>If you blocked it earlier, re-enable the camera in the browser’s site settings, then press <em>Try camera again</em>.</li>
                <li>Camera scanning needs a secure page (HTTPS or localhost) and a browser with built-in QR detection, such as Chrome or Edge on Android.</li>
                <li>Close other apps that may be using the camera.</li>
                <li>If the camera still can’t be used, type or paste the student’s token below — it is verified exactly the same way.</li>
            </ul>
        </details>

        <div class="or-divider"><span>or enter manually</span></div>

        <form id="manual-form" autocomplete="off" novalidate>
            <label for="qr_token">Student QR token</label>
            <input type="text" id="qr_token" name="qr_token" inputmode="text"
                   autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false"
                   placeholder="Paste or type the 64-character token"
                   aria-describedby="token-error">
            <p class="field-error" id="token-error" role="alert" hidden></p>
            <button type="submit" class="primary-btn" id="verify-btn">
                <span>Verify &amp; record</span>
                <span class="spinner" aria-hidden="true"></span>
            </button>
        </form>
    </section>

    <!-- STEP 3: server result. Filled in by assets/js/scanner.js. -->
    <section class="scanner-card result-card" id="step-result" hidden>
        <div class="result-icon" id="result-icon" aria-hidden="true"></div>
        <span class="badge badge-plain result-reason" id="result-reason" hidden></span>
        <h2 class="result-title" id="result-title" tabindex="-1"></h2>
        <p class="result-student" id="result-student"></p>
        <p class="result-message" id="result-message"></p>
        <dl class="result-details" id="result-details"></dl>
        <div class="result-actions">
            <button type="button" class="primary-btn" id="scan-next"></button>
            <button type="button" class="secondary-btn" id="result-change-action">Change action</button>
        </div>
    </section>
</div>
<?php renderPageEnd(['/assets/js/qrscanner.min.js', '/assets/js/scanner.js']); ?>
