<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../config/database.php';

requireRole('ADMIN');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die('Method not allowed.');
}

if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
    http_response_code(400);
    die('Invalid request.');
}

$studentId = (int) ($_POST['id'] ?? 0);
if ($studentId <= 0) {
    http_response_code(400);
    die('Invalid student.');
}

$pdo = getDBConnection();

$stmt = $pdo->prepare('SELECT id, user_id, status FROM students WHERE id = ?');
$stmt->execute([$studentId]);
$student = $stmt->fetch();

if (!$student) {
    http_response_code(404);
    die('Student not found.');
}

$newStatus = $student['status'] === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';

try {
    $pdo->beginTransaction();

    // Deactivating a student also blocks their ability to log in and vice versa --
    // access verification and account access should stay consistent.
    $stmt = $pdo->prepare('UPDATE students SET status = ? WHERE id = ?');
    $stmt->execute([$newStatus, $studentId]);

    $stmt = $pdo->prepare('UPDATE users SET status = ? WHERE id = ?');
    $stmt->execute([$newStatus, $student['user_id']]);

    $pdo->commit();
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log('Student status toggle failed: ' . $e->getMessage());
    http_response_code(500);
    die('A system error occurred. No changes were saved.');
}

header('Location: ' . url('/admin/students.php?status_updated=1'));
exit;
