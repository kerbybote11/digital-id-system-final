<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/validation.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../config/database.php';

requireRole('ADMIN');

$pdo = getDBConnection();
$errors = [];

$studentId = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
if ($studentId <= 0) {
    http_response_code(400);
    die('Invalid student.');
}

$stmt = $pdo->prepare('SELECT * FROM students WHERE id = ?');
$stmt->execute([$studentId]);
$student = $stmt->fetch();

if (!$student) {
    http_response_code(404);
    die('Student not found.');
}

$values = [
    'first_name' => $student['first_name'],
    'last_name'  => $student['last_name'],
    'course'     => $student['course'],
    'year_level' => $student['year_level'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Invalid request. Please refresh the page and try again.';
    } else {
        foreach ($values as $key => $_) {
            $values[$key] = trim((string) ($_POST[$key] ?? ''));
        }

        $checks = [
            validateName($values['first_name'], 'First name'),
            validateName($values['last_name'], 'Last name'),
            validateCourse($values['course']),
            validateYearLevel($values['year_level']),
        ];
        foreach ($checks as $err) {
            if ($err !== '') {
                $errors[] = $err;
            }
        }

        if (empty($errors)) {
            $stmt = $pdo->prepare(
                'UPDATE students
                 SET first_name = ?, last_name = ?, course = ?, year_level = ?
                 WHERE id = ?'
            );
            $stmt->execute([
                $values['first_name'],
                $values['last_name'],
                $values['course'],
                $values['year_level'],
                $studentId,
            ]);

            header('Location: ' . url('/admin/students.php?updated=1'));
            exit;
        }
    }
}

$fieldErrors = mapStudentFormErrors($errors);
$fullName = $student['first_name'] . ' ' . $student['last_name'];

renderPageStart('Edit Student', [
    'active'   => 'students',
    'subtitle' => $fullName . ' · ' . $student['student_id'],
]);
?>
<a class="back-link" href="<?= e(url('/admin/students.php')) ?>"><?= icon('arrow-left', 'icon icon-sm') ?>Back to students</a>

<?php if ($errors): ?>
    <div class="alert-stack">
        <?= renderAlert('error', $errors, count($errors) === 1 ? 'Please fix the following:' : 'Please fix the following ' . count($errors) . ' issues:') ?>
    </div>
<?php endif; ?>

<div class="grid grid-main-aside">
    <form method="POST" action="<?= e(url('/admin/student-edit.php')) ?>?id=<?= $studentId ?>" class="card" data-loading>
        <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
        <input type="hidden" name="id" value="<?= $studentId ?>">

        <div class="card-header">
            <div>
                <h2>Student information</h2>
                <p>Update the student’s name, course and year level.</p>
            </div>
        </div>
        <div class="card-body">
            <div class="form-grid">
                <div class="form-group span-2">
                    <span class="form-label" id="sid-label">Student ID</span>
                    <div class="readonly-field"><?= icon('lock', 'icon icon-sm') ?><?= e($student['student_id']) ?></div>
                    <p class="form-hint">The Student ID can’t be changed here.</p>
                </div>
                <?= formField(['name' => 'first_name', 'label' => 'First name', 'value' => $values['first_name'], 'required' => true,
                    'maxlength' => 100, 'autocomplete' => 'off', 'errors' => $fieldErrors['first_name'] ?? []]) ?>
                <?= formField(['name' => 'last_name', 'label' => 'Last name', 'value' => $values['last_name'], 'required' => true,
                    'maxlength' => 100, 'autocomplete' => 'off', 'errors' => $fieldErrors['last_name'] ?? []]) ?>
                <?= formField(['name' => 'course', 'label' => 'Course', 'value' => $values['course'], 'required' => true,
                    'maxlength' => 100, 'errors' => $fieldErrors['course'] ?? []]) ?>
                <?= formField(['name' => 'year_level', 'label' => 'Year level', 'value' => $values['year_level'], 'required' => true,
                    'maxlength' => 20, 'list' => 'year-level-options', 'errors' => $fieldErrors['year_level'] ?? []]) ?>
            </div>
        </div>
        <div class="card-footer">
            <a class="btn btn-secondary" href="<?= e(url('/admin/students.php')) ?>">Cancel</a>
            <button type="submit" class="btn btn-primary"><span>Save changes</span><span class="spinner" aria-hidden="true"></span></button>
        </div>
    </form>

    <aside class="card" aria-labelledby="status-heading">
        <div class="card-header">
            <div>
                <h2 id="status-heading">Account &amp; access</h2>
                <p>Current status of this student.</p>
            </div>
        </div>
        <div class="card-body">
            <dl class="detail-list">
                <dt>Account</dt>
                <dd><?= accountStatusBadge($student['status']) ?></dd>
                <dt>Access status</dt>
                <dd><?= accessBadge($student['current_status']) ?></dd>
                <dt>Created</dt>
                <dd><?= e(formatDateTime($student['created_at'])) ?></dd>
                <dt>Last updated</dt>
                <dd><?= e(formatDateTime($student['updated_at'])) ?></dd>
            </dl>
        </div>
        <div class="card-footer">
            <?php $isActive = $student['status'] === 'ACTIVE'; ?>
            <form method="POST" action="<?= e(url('/admin/student-toggle-status.php')) ?>"
                  data-confirm-title="<?= $isActive ? 'Deactivate' : 'Activate' ?> <?= e($fullName) ?>?"
                  data-confirm="<?= $isActive
                      ? 'This student will no longer be able to sign in, and their QR codes will be rejected at the scanner until the account is activated again.'
                      : 'This student will be able to sign in and generate QR codes again.' ?>"
                  data-confirm-ok="<?= $isActive ? 'Deactivate' : 'Activate' ?>"
                  data-confirm-variant="<?= $isActive ? 'danger' : 'primary' ?>">
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <input type="hidden" name="id" value="<?= $studentId ?>">
                <button type="submit" class="btn <?= $isActive ? 'btn-danger-outline' : 'btn-success-outline' ?>">
                    <?= icon('power', 'icon icon-sm') ?><?= $isActive ? 'Deactivate student' : 'Activate student' ?>
                </button>
            </form>
        </div>
    </aside>
</div>

<datalist id="year-level-options">
    <option value="1st Year"></option>
    <option value="2nd Year"></option>
    <option value="3rd Year"></option>
    <option value="4th Year"></option>
    <option value="5th Year"></option>
</datalist>
<?php renderPageEnd(); ?>
