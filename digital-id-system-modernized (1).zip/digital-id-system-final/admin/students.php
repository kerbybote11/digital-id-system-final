<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../config/database.php';

requireRole('ADMIN');

$pdo = getDBConnection();

// --- Search / filter (all via prepared statement, never raw-concatenated) ---
$search = trim((string) ($_GET['q'] ?? ''));
$statusFilter = $_GET['status'] ?? '';
$statusFilter = in_array($statusFilter, ['ACTIVE', 'INACTIVE'], true) ? $statusFilter : '';

$sql = 'SELECT id, student_id, first_name, last_name, course, year_level, status, current_status
        FROM students WHERE 1=1';
$params = [];

if ($search !== '') {
    // Distinct placeholder names: with native prepares (EMULATE_PREPARES =
    // false) PDO MySQL rejects a named parameter that appears more than once.
    $sql .= ' AND (student_id LIKE :search1
                   OR first_name LIKE :search2
                   OR last_name LIKE :search3
                   OR course LIKE :search4)';
    $like = '%' . $search . '%';
    $params[':search1'] = $params[':search2'] = $params[':search3'] = $params[':search4'] = $like;
}

if ($statusFilter !== '') {
    $sql .= ' AND status = :status';
    $params[':status'] = $statusFilter;
}

$sql .= ' ORDER BY last_name, first_name';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$students = $stmt->fetchAll();

// Feedback after redirects from student-add / student-edit / student-toggle-status.
$flash = [];
if (isset($_GET['added']))          { $flash[] = 'Student created. They can now sign in with the username and temporary password you set.'; }
if (isset($_GET['updated']))        { $flash[] = 'Student details saved.'; }
if (isset($_GET['status_updated'])) { $flash[] = 'Student status updated.'; }

$isFiltered = $search !== '' || $statusFilter !== '';

renderPageStart('Students', [
    'active'   => 'students',
    'subtitle' => 'Manage student profiles, login accounts and status',
]);
?>
<?php if ($flash): ?>
    <div class="alert-stack">
        <?php foreach ($flash as $msg): ?><?= renderAlert('success', $msg, '', true) ?><?php endforeach; ?>
    </div>
<?php endif; ?>

<section class="card card-flush" aria-labelledby="students-heading">
    <div class="card-header">
        <div>
            <h2 id="students-heading">Student directory</h2>
            <p>Deactivating a student also blocks their login and QR verification.</p>
        </div>
        <a href="<?= e(url('/admin/student-add.php')) ?>" class="btn btn-primary"><?= icon('plus') ?>Add student</a>
    </div>

    <form method="GET" action="<?= e(url('/admin/students.php')) ?>" class="toolbar" role="search" aria-label="Filter students">
        <div class="form-group grow">
            <label class="form-label" for="q">Search</label>
            <div class="input-group">
                <?= icon('search', 'icon input-icon') ?>
                <input class="form-control" type="search" id="q" name="q" placeholder="Student ID, name or course"
                       value="<?= e($search) ?>">
            </div>
        </div>
        <div class="form-group">
            <label class="form-label" for="status">Account status</label>
            <select class="form-control" id="status" name="status">
                <option value="">All statuses</option>
                <option value="ACTIVE" <?= $statusFilter === 'ACTIVE' ? 'selected' : '' ?>>Active</option>
                <option value="INACTIVE" <?= $statusFilter === 'INACTIVE' ? 'selected' : '' ?>>Inactive</option>
            </select>
        </div>
        <div class="toolbar-actions">
            <button type="submit" class="btn btn-primary"><?= icon('search', 'icon icon-sm') ?>Search</button>
            <?php if ($isFiltered): ?>
                <a href="<?= e(url('/admin/students.php')) ?>" class="btn btn-secondary">Clear</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="result-meta">
        <span><strong><?= count($students) ?></strong> student<?= count($students) === 1 ? '' : 's' ?><?= $isFiltered ? ' match your filters' : '' ?></span>
    </div>

    <?php if (empty($students)): ?>
        <?php if ($isFiltered): ?>
            <?= renderEmptyState('No students match', 'Try a different search term or clear the filters.', 'search',
                '<a class="btn btn-secondary" href="' . e(url('/admin/students.php')) . '">Clear filters</a>') ?>
        <?php else: ?>
            <?= renderEmptyState('No students yet', 'Add your first student to create their profile and login account.', 'users',
                '<a class="btn btn-primary" href="' . e(url('/admin/student-add.php')) . '">' . icon('plus') . 'Add student</a>') ?>
        <?php endif; ?>
    <?php else: ?>
        <div class="table-wrap">
            <table class="data-table table-stack">
                <thead>
                    <tr>
                        <th scope="col">Student</th>
                        <th scope="col">Course</th>
                        <th scope="col">Year</th>
                        <th scope="col">Account</th>
                        <th scope="col">Access</th>
                        <th scope="col" class="col-actions">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($students as $s):
                    $fullName = $s['first_name'] . ' ' . $s['last_name'];
                    $isActive = $s['status'] === 'ACTIVE';
                ?>
                    <tr>
                        <td class="cell-lead" data-label="Student">
                            <span class="person">
                                <span class="avatar" aria-hidden="true"><?= e(initials($fullName)) ?></span>
                                <span>
                                    <span class="cell-primary"><?= e($s['last_name'] . ', ' . $s['first_name']) ?></span>
                                    <span class="cell-secondary mono"><?= e($s['student_id']) ?></span>
                                </span>
                            </span>
                        </td>
                        <td data-label="Course"><?= e($s['course']) ?></td>
                        <td data-label="Year" class="nowrap"><?= e($s['year_level']) ?></td>
                        <td data-label="Account"><?= accountStatusBadge($s['status']) ?></td>
                        <td data-label="Access"><?= accessBadge($s['current_status']) ?></td>
                        <td class="col-actions">
                            <div class="row-actions">
                                <a class="btn btn-secondary btn-sm" href="<?= e(url('/admin/student-edit.php')) ?>?id=<?= (int) $s['id'] ?>"
                                   aria-label="Edit <?= e($fullName) ?>"><?= icon('edit', 'icon icon-sm') ?>Edit</a>
                                <form method="POST" action="<?= e(url('/admin/student-toggle-status.php')) ?>"
                                      data-confirm-title="<?= $isActive ? 'Deactivate' : 'Activate' ?> <?= e($fullName) ?>?"
                                      data-confirm="<?= $isActive
                                          ? 'This student will no longer be able to sign in, and their QR codes will be rejected at the scanner until the account is activated again.'
                                          : 'This student will be able to sign in and generate QR codes again.' ?>"
                                      data-confirm-ok="<?= $isActive ? 'Deactivate' : 'Activate' ?>"
                                      data-confirm-variant="<?= $isActive ? 'danger' : 'primary' ?>">
                                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                    <input type="hidden" name="id" value="<?= (int) $s['id'] ?>">
                                    <button type="submit" class="btn btn-sm <?= $isActive ? 'btn-danger-outline' : 'btn-success-outline' ?>"
                                            aria-label="<?= $isActive ? 'Deactivate' : 'Activate' ?> <?= e($fullName) ?>">
                                        <?= icon('power', 'icon icon-sm') ?><?= $isActive ? 'Deactivate' : 'Activate' ?>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
<?php renderPageEnd(); ?>
