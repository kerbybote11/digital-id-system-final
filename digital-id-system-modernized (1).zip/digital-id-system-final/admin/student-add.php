<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/validation.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../config/database.php';

requireRole('ADMIN');

$pdo = getDBConnection();
$errors = [];
$values = [
    'student_id' => '', 'first_name' => '', 'last_name' => '',
    'course' => '', 'year_level' => '', 'username' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Invalid request. Please refresh the page and try again.';
    } else {
        foreach ($values as $key => $_) {
            $values[$key] = trim((string) ($_POST[$key] ?? ''));
        }
        $tempPassword = (string) ($_POST['temp_password'] ?? '');

        // --- Field validation ---
        $checks = [
            validateStudentIdFormat($values['student_id']),
            validateName($values['first_name'], 'First name'),
            validateName($values['last_name'], 'Last name'),
            validateCourse($values['course']),
            validateYearLevel($values['year_level']),
            validateUsernameFormat($values['username']),
            validateTemporaryPassword($tempPassword),
        ];
        foreach ($checks as $err) {
            if ($err !== '') {
                $errors[] = $err;
            }
        }

        // --- Uniqueness checks ---
        if (empty($errors)) {
            $stmt = $pdo->prepare('SELECT id FROM students WHERE student_id = ?');
            $stmt->execute([$values['student_id']]);
            if ($stmt->fetch()) {
                $errors[] = 'That Student ID is already in use.';
            }

            $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ?');
            $stmt->execute([$values['username']]);
            if ($stmt->fetch()) {
                $errors[] = 'That username is already in use.';
            }
        }

        // --- Create user + student together, or neither ---
        if (empty($errors)) {
            try {
                $pdo->beginTransaction();

                $passwordHash = password_hash($tempPassword, PASSWORD_BCRYPT);

                $stmt = $pdo->prepare(
                    'INSERT INTO users (username, password_hash, role, status)
                     VALUES (?, ?, ?, ?)'
                );
                $stmt->execute([$values['username'], $passwordHash, 'STUDENT', 'ACTIVE']);
                $newUserId = (int) $pdo->lastInsertId();

                $stmt = $pdo->prepare(
                    'INSERT INTO students
                        (user_id, student_id, first_name, last_name, course, year_level, status, current_status)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
                );
                $stmt->execute([
                    $newUserId,
                    $values['student_id'],
                    $values['first_name'],
                    $values['last_name'],
                    $values['course'],
                    $values['year_level'],
                    'ACTIVE',
                    'OUT',
                ]);

                $pdo->commit();

                // Drop the temporary password from memory immediately after use.
                $tempPassword = '';
                unset($tempPassword, $passwordHash);

                header('Location: ' . url('/admin/students.php?added=1'));
                exit;
            } catch (PDOException $e) {
                $pdo->rollBack();
                error_log('Student creation failed: ' . $e->getMessage());
                $errors[] = 'A system error occurred while creating the student. No changes were saved.';
            }
        }
    }
}

$fieldErrors = mapStudentFormErrors($errors);

renderPageStart('Add Student', [
    'active'   => 'students',
    'subtitle' => 'Create a student profile and login account',
]);
?>
<a class="back-link" href="<?= e(url('/admin/students.php')) ?>"><?= icon('arrow-left', 'icon icon-sm') ?>Back to students</a>

<?php if ($errors): ?>
    <div class="alert-stack">
        <?= renderAlert('error', $errors, count($errors) === 1 ? 'Please fix the following:' : 'Please fix the following ' . count($errors) . ' issues:') ?>
    </div>
<?php endif; ?>

<form method="POST" action="<?= e(url('/admin/student-add.php')) ?>" class="card" data-loading>
    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

    <div class="card-body">
        <section class="form-section" aria-labelledby="info-heading">
            <h2 class="form-section-title" id="info-heading">Student information</h2>
            <p class="form-section-desc">Fields marked <span class="req" aria-hidden="true">*</span><span class="sr-only">with an asterisk</span> are required.</p>
            <div class="form-grid">
                <?= formField(['name' => 'student_id', 'label' => 'Student ID', 'value' => $values['student_id'], 'required' => true,
                    'maxlength' => 30, 'hint' => 'Letters, numbers and hyphens only. Cannot be changed later.',
                    'errors' => $fieldErrors['student_id'] ?? [], 'spellcheck_off' => true, 'span2' => true]) ?>
                <?= formField(['name' => 'first_name', 'label' => 'First name', 'value' => $values['first_name'], 'required' => true,
                    'maxlength' => 100, 'autocomplete' => 'off', 'errors' => $fieldErrors['first_name'] ?? []]) ?>
                <?= formField(['name' => 'last_name', 'label' => 'Last name', 'value' => $values['last_name'], 'required' => true,
                    'maxlength' => 100, 'autocomplete' => 'off', 'errors' => $fieldErrors['last_name'] ?? []]) ?>
                <?= formField(['name' => 'course', 'label' => 'Course', 'value' => $values['course'], 'required' => true,
                    'maxlength' => 100, 'placeholder' => 'e.g. BS Information Technology', 'errors' => $fieldErrors['course'] ?? []]) ?>
                <?= formField(['name' => 'year_level', 'label' => 'Year level', 'value' => $values['year_level'], 'required' => true,
                    'maxlength' => 20, 'list' => 'year-level-options', 'placeholder' => 'e.g. 1st Year',
                    'errors' => $fieldErrors['year_level'] ?? []]) ?>
            </div>
        </section>

        <section class="form-section" aria-labelledby="account-heading">
            <h2 class="form-section-title" id="account-heading">Login account</h2>
            <p class="form-section-desc">The student signs in with these credentials. Share the temporary password securely — it is stored only as a secure hash.</p>
            <div class="form-grid">
                <?= formField(['name' => 'username', 'label' => 'Username', 'value' => $values['username'], 'required' => true,
                    'minlength' => 3, 'maxlength' => 50, 'autocomplete' => 'off', 'spellcheck_off' => true,
                    'hint' => '3–50 characters: letters, numbers and underscores.', 'errors' => $fieldErrors['username'] ?? []]) ?>
                <?= formField(['name' => 'temp_password', 'label' => 'Temporary password', 'type' => 'password', 'required' => true,
                    'minlength' => 8, 'autocomplete' => 'new-password',
                    'hint' => 'At least 8 characters.', 'errors' => $fieldErrors['temp_password'] ?? []]) ?>
            </div>
        </section>
    </div>

    <div class="card-footer">
        <a class="btn btn-secondary" href="<?= e(url('/admin/students.php')) ?>">Cancel</a>
        <button type="submit" class="btn btn-primary">
            <?= icon('user-plus', 'icon icon-sm') ?><span>Create student</span><span class="spinner" aria-hidden="true"></span>
        </button>
    </div>
</form>

<datalist id="year-level-options">
    <option value="1st Year"></option>
    <option value="2nd Year"></option>
    <option value="3rd Year"></option>
    <option value="4th Year"></option>
    <option value="5th Year"></option>
</datalist>
<?php renderPageEnd(); ?>
