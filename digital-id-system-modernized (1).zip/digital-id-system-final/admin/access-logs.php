<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/reports.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../config/database.php';

requireRole('ADMIN');

$pdo = getDBConnection();

$filters = sanitizeAccessLogFilters($_GET);
$result = searchAccessTransactions($pdo, $filters, 20);

/**
 * Rebuilds the query string for pagination links, preserving the current
 * filters but swapping in a different page number.
 */
function buildPageUrl(array $filters, int $page): string
{
    $params = [
        'q'         => $filters['search'],
        'type'      => $filters['type'],
        'date_from' => $filters['date_from'],
        'date_to'   => $filters['date_to'],
        'page'      => $page,
    ];
    // Drop empty values so the URL stays clean.
    $params = array_filter($params, static fn ($v) => $v !== '' && $v !== null);
    return url('/admin/access-logs.php') . '?' . http_build_query($params);
}

$isFiltered = $filters['search'] !== '' || $filters['type'] !== '' || $filters['date_from'] !== '' || $filters['date_to'] !== '';
$pageSize   = 20;
$firstRow   = $result['total_count'] > 0 ? ($result['page'] - 1) * $pageSize + 1 : 0;
$lastRow    = min($result['page'] * $pageSize, $result['total_count']);

// Compact page-number window: 1 … (p-1) p (p+1) … N
$pageNumbers = [];
for ($n = 1; $n <= $result['total_pages']; $n++) {
    if ($n === 1 || $n === $result['total_pages'] || abs($n - $result['page']) <= 1) {
        $pageNumbers[] = $n;
    }
}

renderPageStart('Access Logs', [
    'active'   => 'logs',
    'subtitle' => 'Complete IN/OUT history recorded by scanner staff',
]);
?>
<section class="card card-flush" aria-labelledby="logs-heading">
    <div class="card-header">
        <div>
            <h2 id="logs-heading">Access history</h2>
            <p>Records are read-only and listed newest first.</p>
        </div>
    </div>

    <form method="GET" action="<?= e(url('/admin/access-logs.php')) ?>" class="toolbar toolbar-grid" role="search" aria-label="Filter access logs">
        <div class="form-group grow">
            <label class="form-label" for="q">Search</label>
            <div class="input-group">
                <?= icon('search', 'icon input-icon') ?>
                <input class="form-control" type="search" id="q" name="q" placeholder="Student ID or name"
                       value="<?= e($filters['search']) ?>">
            </div>
        </div>
        <div class="form-group">
            <label class="form-label" for="type">Action</label>
            <select class="form-control" id="type" name="type">
                <option value="">All actions</option>
                <option value="IN"  <?= $filters['type'] === 'IN'  ? 'selected' : '' ?>>IN (entry)</option>
                <option value="OUT" <?= $filters['type'] === 'OUT' ? 'selected' : '' ?>>OUT (exit)</option>
            </select>
        </div>
        <div class="form-group">
            <label class="form-label" for="date_from">From</label>
            <input class="form-control" type="date" id="date_from" name="date_from" value="<?= e($filters['date_from']) ?>">
        </div>
        <div class="form-group">
            <label class="form-label" for="date_to">To</label>
            <input class="form-control" type="date" id="date_to" name="date_to" value="<?= e($filters['date_to']) ?>">
        </div>
        <div class="toolbar-actions">
            <button type="submit" class="btn btn-primary"><?= icon('search', 'icon icon-sm') ?>Apply</button>
            <?php if ($isFiltered): ?>
                <a href="<?= e(url('/admin/access-logs.php')) ?>" class="btn btn-secondary">Clear</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="result-meta">
        <span><strong><?= (int) $result['total_count'] ?></strong> record<?= (int) $result['total_count'] === 1 ? '' : 's' ?> found<?= $isFiltered ? ' for your filters' : '' ?></span>
        <?php if ($result['total_count'] > 0): ?>
            <span>Showing <?= $firstRow ?>–<?= $lastRow ?></span>
        <?php endif; ?>
    </div>

    <?php if (empty($result['rows'])): ?>
        <?php if ($isFiltered): ?>
            <?= renderEmptyState('No matching records', 'No access records match these filters. Try widening the date range or clearing the search.', 'search',
                '<a class="btn btn-secondary" href="' . e(url('/admin/access-logs.php')) . '">Clear filters</a>') ?>
        <?php else: ?>
            <?= renderEmptyState('No access records yet', 'Records appear here as scanner staff verify student QR codes.', 'list') ?>
        <?php endif; ?>
    <?php else: ?>
        <div class="table-wrap">
            <table class="data-table table-stack">
                <thead>
                    <tr>
                        <th scope="col">Student</th>
                        <th scope="col">Action</th>
                        <th scope="col">Time</th>
                        <th scope="col">Scanned by</th>
                        <th scope="col">QR ref</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($result['rows'] as $t): ?>
                    <tr>
                        <td class="cell-lead" data-label="Student">
                            <span class="person">
                                <span class="avatar" aria-hidden="true"><?= e(initials($t['first_name'] . ' ' . $t['last_name'])) ?></span>
                                <span>
                                    <span class="cell-primary"><?= e($t['last_name'] . ', ' . $t['first_name']) ?></span>
                                    <span class="cell-secondary mono"><?= e($t['student_id']) ?></span>
                                </span>
                            </span>
                        </td>
                        <td data-label="Action"><?= accessBadge($t['transaction_type']) ?></td>
                        <td data-label="Time" class="cell-time"><?= timeCell($t['timestamp']) ?></td>
                        <td data-label="Scanned by"><?= e($t['scanner_username']) ?></td>
                        <td data-label="QR ref" class="cell-id"><?= $t['qr_credential_id'] !== null ? 'QR #' . (int) $t['qr_credential_id'] : '&mdash;' ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <?php if ($result['total_pages'] > 1): ?>
        <nav class="pagination" aria-label="Access log pages">
            <span class="pagination-info">Page <?= (int) $result['page'] ?> of <?= (int) $result['total_pages'] ?></span>
            <ul class="pagination-list">
                <li>
                    <?php if ($result['page'] > 1): ?>
                        <a class="page-link" href="<?= e(buildPageUrl($filters, $result['page'] - 1)) ?>" rel="prev"><?= icon('chevron-left', 'icon icon-sm') ?><span>Previous</span></a>
                    <?php else: ?>
                        <span class="page-link is-disabled" aria-disabled="true"><?= icon('chevron-left', 'icon icon-sm') ?><span>Previous</span></span>
                    <?php endif; ?>
                </li>
                <?php $prev = 0; foreach ($pageNumbers as $n): ?>
                    <?php if ($n - $prev > 1): ?><li class="page-gap" aria-hidden="true">&hellip;</li><?php endif; ?>
                    <li>
                        <a class="page-link" href="<?= e(buildPageUrl($filters, $n)) ?>"
                           <?= $n === (int) $result['page'] ? 'aria-current="page"' : '' ?>
                           aria-label="Page <?= $n ?>"><?= $n ?></a>
                    </li>
                <?php $prev = $n; endforeach; ?>
                <li>
                    <?php if ($result['page'] < $result['total_pages']): ?>
                        <a class="page-link" href="<?= e(buildPageUrl($filters, $result['page'] + 1)) ?>" rel="next"><span>Next</span><?= icon('chevron-right', 'icon icon-sm') ?></a>
                    <?php else: ?>
                        <span class="page-link is-disabled" aria-disabled="true"><span>Next</span><?= icon('chevron-right', 'icon icon-sm') ?></span>
                    <?php endif; ?>
                </li>
            </ul>
        </nav>
    <?php endif; ?>
</section>
<?php renderPageEnd(); ?>
