<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/reports.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../config/database.php';

requireRole('ADMIN');

$pdo = getDBConnection();

$stats = getDashboardStats($pdo);
$recentTransactions = getRecentTransactions($pdo, 10);

renderPageStart('Dashboard', [
    'active'   => 'dashboard',
    'subtitle' => 'Campus access overview · ' . date('l, F j, Y'),
]);
?>
<div class="stack-lg">
    <section aria-labelledby="stats-heading">
        <h2 id="stats-heading" class="sr-only">Summary</h2>
        <div class="stats-grid">
            <article class="stat-card">
                <div class="stat-head">
                    <span class="stat-label">Total students</span>
                    <span class="stat-icon"><?= icon('users') ?></span>
                </div>
                <span class="stat-value"><?= (int) $stats['total_students'] ?></span>
                <div class="stat-meta">
                    <span><strong><?= (int) $stats['active_students'] ?></strong> active</span>
                    <span><strong><?= (int) $stats['inactive_students'] ?></strong> inactive</span>
                </div>
            </article>

            <article class="stat-card">
                <div class="stat-head">
                    <span class="stat-label">Currently on campus</span>
                    <span class="stat-icon tone-success"><?= icon('arrow-in') ?></span>
                </div>
                <span class="stat-value"><?= (int) $stats['currently_in'] ?></span>
                <div class="stat-meta">
                    <span>Students with status <strong>IN</strong></span>
                    <span><strong><?= (int) $stats['currently_out'] ?></strong> currently OUT</span>
                </div>
            </article>

            <article class="stat-card">
                <div class="stat-head">
                    <span class="stat-label">Entries today</span>
                    <span class="stat-icon tone-success"><?= icon('login') ?></span>
                </div>
                <span class="stat-value"><?= (int) $stats['today_in'] ?></span>
                <div class="stat-meta"><span>IN transactions recorded today</span></div>
            </article>

            <article class="stat-card">
                <div class="stat-head">
                    <span class="stat-label">Exits today</span>
                    <span class="stat-icon tone-warning"><?= icon('logout') ?></span>
                </div>
                <span class="stat-value"><?= (int) $stats['today_out'] ?></span>
                <div class="stat-meta"><span>OUT transactions recorded today</span></div>
            </article>
        </div>
    </section>

    <div class="grid grid-main-aside">
        <section class="card card-flush" aria-labelledby="recent-heading">
            <div class="card-header">
                <div>
                    <h2 id="recent-heading">Recent access activity</h2>
                    <p>The 10 most recent IN/OUT transactions.</p>
                </div>
                <a class="btn btn-secondary btn-sm" href="<?= e(url('/admin/access-logs.php')) ?>">View full log <?= icon('arrow-right', 'icon icon-sm') ?></a>
            </div>

            <?php if (empty($recentTransactions)): ?>
                <?= renderEmptyState('No access activity yet', 'Transactions appear here as soon as scanner staff record a student IN or OUT.', 'activity') ?>
            <?php else: ?>
                <div class="table-wrap">
                    <table class="data-table table-stack">
                        <thead>
                            <tr>
                                <th scope="col">Student</th>
                                <th scope="col">Action</th>
                                <th scope="col">Time</th>
                                <th scope="col">Scanned by</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($recentTransactions as $t): ?>
                            <tr>
                                <td class="cell-lead" data-label="Student">
                                    <span class="person">
                                        <span class="avatar" aria-hidden="true"><?= e(initials($t['first_name'] . ' ' . $t['last_name'])) ?></span>
                                        <span>
                                            <span class="cell-primary"><?= e($t['last_name'] . ', ' . $t['first_name']) ?></span>
                                            <span class="cell-secondary mono"><?= e($t['student_id']) ?></span>
                                        </span>
                                    </span>
                                </td>
                                <td data-label="Action"><?= accessBadge($t['transaction_type']) ?></td>
                                <td data-label="Time" class="cell-time"><?= timeCell($t['timestamp']) ?></td>
                                <td data-label="Scanned by"><?= e($t['scanner_username']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>

        <section class="card" aria-labelledby="shortcuts-heading">
            <div class="card-header">
                <div>
                    <h2 id="shortcuts-heading">Quick actions</h2>
                    <p>Jump to a management page.</p>
                </div>
            </div>
            <nav class="quick-links" aria-label="Quick actions">
                <a class="quick-link" href="<?= e(url('/admin/student-add.php')) ?>">
                    <span class="stat-icon"><?= icon('user-plus') ?></span>
                    <span class="quick-link-text"><strong>Add a student</strong><span>Create a profile and login account</span></span>
                    <?= icon('chevron-right') ?>
                </a>
                <a class="quick-link" href="<?= e(url('/admin/students.php')) ?>">
                    <span class="stat-icon"><?= icon('users') ?></span>
                    <span class="quick-link-text"><strong>Manage students</strong><span>Search, edit, activate or deactivate</span></span>
                    <?= icon('chevron-right') ?>
                </a>
                <a class="quick-link" href="<?= e(url('/admin/qr-management.php')) ?>">
                    <span class="stat-icon"><?= icon('qr') ?></span>
                    <span class="quick-link-text"><strong>QR credentials</strong><span>Review and revoke temporary QR codes</span></span>
                    <?= icon('chevron-right') ?>
                </a>
                <a class="quick-link" href="<?= e(url('/admin/access-logs.php')) ?>">
                    <span class="stat-icon"><?= icon('list') ?></span>
                    <span class="quick-link-text"><strong>Access logs</strong><span>Search the full IN/OUT history</span></span>
                    <?= icon('chevron-right') ?>
                </a>
            </nav>
        </section>
    </div>
</div>
<?php renderPageEnd(); ?>
