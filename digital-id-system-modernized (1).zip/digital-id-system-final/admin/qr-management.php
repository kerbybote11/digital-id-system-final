<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/qr.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../config/database.php';

requireRole('ADMIN');

$pdo = getDBConnection();
$message = '';

// Handle revoke action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'revoke') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        die('Invalid request.');
    }
    $credentialId = (int) ($_POST['credential_id'] ?? 0);
    if ($credentialId > 0) {
        revokeQrCredential($pdo, $credentialId);
    }
    header('Location: ' . url('/admin/qr-management.php?revoked=1'));
    exit;
}

$search = trim((string) ($_GET['q'] ?? ''));

$sql = "SELECT qr.id, qr.created_at, qr.expires_at, qr.status, qr.revoked_at,
               (qr.expires_at < NOW()) AS is_past_expiry,
               s.student_id, s.first_name, s.last_name
        FROM qr_credentials qr
        JOIN students s ON s.id = qr.student_id";
$params = [];

if ($search !== '') {
    // Distinct placeholder names (a repeated named parameter fails with
    // native prepares -- see admin/students.php).
    $sql .= ' WHERE s.student_id LIKE :search1
               OR s.first_name LIKE :search2
               OR s.last_name LIKE :search3';
    $like = '%' . $search . '%';
    $params[':search1'] = $params[':search2'] = $params[':search3'] = $like;
}

$sql .= ' ORDER BY qr.created_at DESC LIMIT 200';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$credentials = $stmt->fetchAll();

// Lazily reflect expiry in what the admin sees, without mutating rows
// outside their own lazy-expiry function (keeps this page read-mostly).
// (Expiry is compared by MySQL -- see is_past_expiry above -- so the result
// doesn't depend on PHP's time zone matching the database's.)
foreach ($credentials as &$c) {
    if ($c['status'] === 'ACTIVE' && (int) $c['is_past_expiry'] === 1) {
        $c['status'] = 'EXPIRED (pending sync)';
    }
}
unset($c);

renderPageStart('QR Credentials', [
    'active'   => 'qr',
    'subtitle' => 'Review and revoke temporary student QR codes',
]);
?>
<?php if (isset($_GET['revoked'])): ?>
    <div class="alert-stack"><?= renderAlert('success', 'Credential revoked. That QR code will now be rejected at the scanner.', '', true) ?></div>
<?php endif; ?>

<section class="card card-flush" aria-labelledby="qr-heading">
    <div class="card-header">
        <div>
            <h2 id="qr-heading">Issued credentials</h2>
            <p>Each student has at most one active QR. Generating a new one automatically revokes the previous code.</p>
        </div>
    </div>

    <form method="GET" action="<?= e(url('/admin/qr-management.php')) ?>" class="toolbar" role="search" aria-label="Search QR credentials">
        <div class="form-group grow">
            <label class="form-label" for="q">Search</label>
            <div class="input-group">
                <?= icon('search', 'icon input-icon') ?>
                <input class="form-control" type="search" id="q" name="q" placeholder="Student ID or name"
                       value="<?= e($search) ?>">
            </div>
        </div>
        <div class="toolbar-actions">
            <button type="submit" class="btn btn-primary"><?= icon('search', 'icon icon-sm') ?>Search</button>
            <?php if ($search !== ''): ?>
                <a href="<?= e(url('/admin/qr-management.php')) ?>" class="btn btn-secondary">Clear</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="result-meta">
        <span><strong><?= count($credentials) ?></strong> credential<?= count($credentials) === 1 ? '' : 's' ?><?= $search !== '' ? ' match your search' : '' ?></span>
        <span>Showing up to the 200 most recent</span>
    </div>

    <?php if (empty($credentials)): ?>
        <?php if ($search !== ''): ?>
            <?= renderEmptyState('No credentials match', 'Try a different student ID or name.', 'search',
                '<a class="btn btn-secondary" href="' . e(url('/admin/qr-management.php')) . '">Clear search</a>') ?>
        <?php else: ?>
            <?= renderEmptyState('No QR credentials yet', 'Credentials appear here once students generate a temporary QR code.', 'qr') ?>
        <?php endif; ?>
    <?php else: ?>
        <div class="table-wrap">
            <table class="data-table table-stack">
                <thead>
                    <tr>
                        <th scope="col">Student</th>
                        <th scope="col">Ref</th>
                        <th scope="col">Created</th>
                        <th scope="col">Expires</th>
                        <th scope="col">Status</th>
                        <th scope="col" class="col-actions">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($credentials as $c):
                    $fullName = $c['first_name'] . ' ' . $c['last_name'];
                ?>
                    <tr>
                        <td class="cell-lead" data-label="Student">
                            <span class="person">
                                <span class="avatar" aria-hidden="true"><?= e(initials($fullName)) ?></span>
                                <span>
                                    <span class="cell-primary"><?= e($c['last_name'] . ', ' . $c['first_name']) ?></span>
                                    <span class="cell-secondary mono"><?= e($c['student_id']) ?></span>
                                </span>
                            </span>
                        </td>
                        <td data-label="Ref" class="cell-id">QR #<?= (int) $c['id'] ?></td>
                        <td data-label="Created" class="cell-time"><?= timeCell($c['created_at']) ?></td>
                        <td data-label="Expires" class="cell-time"><?= timeCell($c['expires_at']) ?></td>
                        <td data-label="Status">
                            <?= qrStatusBadge($c['status']) ?>
                            <?php if ($c['status'] === 'REVOKED' && !empty($c['revoked_at'])): ?>
                                <span class="cell-secondary"><?= e(formatDateTime($c['revoked_at'])) ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="col-actions">
                            <?php if ($c['status'] === 'ACTIVE'): ?>
                                <div class="row-actions">
                                    <form method="POST" action="<?= e(url('/admin/qr-management.php')) ?>"
                                          data-confirm-title="Revoke QR #<?= (int) $c['id'] ?>?"
                                          data-confirm="<?= e($fullName) ?>’s current QR code will stop working immediately. They can generate a new one from their portal."
                                          data-confirm-ok="Revoke QR">
                                        <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                        <input type="hidden" name="action" value="revoke">
                                        <input type="hidden" name="credential_id" value="<?= (int) $c['id'] ?>">
                                        <button type="submit" class="btn btn-danger-outline btn-sm"
                                                aria-label="Revoke QR #<?= (int) $c['id'] ?> for <?= e($fullName) ?>">
                                            <?= icon('ban', 'icon icon-sm') ?>Revoke
                                        </button>
                                    </form>
                                </div>
                            <?php else: ?>
                                <span class="muted text-sm" aria-label="No action available">&mdash;</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
<?php renderPageEnd(); ?>
