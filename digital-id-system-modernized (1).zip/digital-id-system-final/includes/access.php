<?php
declare(strict_types=1);

/**
 * Access actions a scanner operator can select. The selected action is sent
 * by the client but is ALWAYS re-validated here on the server.
 */
const ACCESS_ACTIONS = ['IN', 'OUT'];

/**
 * The student status each action requires before it is allowed:
 *   IN  is only valid for a student who is currently OUT  (OUT -> IN)
 *   OUT is only valid for a student who is currently IN   (IN  -> OUT)
 * Anything else (IN->IN, OUT->OUT) is rejected. There is no automatic
 * toggling: the status never changes unless the operator's selected action
 * matches this table.
 */
const ACCESS_REQUIRED_STATUS = ['IN' => 'OUT', 'OUT' => 'IN'];

/**
 * Atomically applies the operator-selected action ('IN' or 'OUT') to a
 * student and records the matching access_transactions row.
 *
 * Flow (all inside one DB transaction):
 *   BEGIN -> lock the student row (SELECT ... FOR UPDATE) -> read the status
 *   -> check the selected action against that status ->
 *       valid:   INSERT transaction + UPDATE status, COMMIT
 *       invalid: ROLLBACK (no row written, status untouched)
 *
 * The locking read serializes concurrent scans of the same student: a second,
 * nearly simultaneous request blocks at the SELECT until the first finishes,
 * then sees the committed status and is accepted or rejected accordingly, so
 * duplicate IN/IN or OUT/OUT transactions cannot occur.
 *
 * This function does NOT validate the QR credential -- callers must have
 * done that via validateQrTokenForScan() (performScanAction() below does).
 * It never changes qr_credentials.status; QR validity and access status are
 * independent.
 */
function processAccessTransition(
    PDO $pdo,
    int $studentId,
    int $qrCredentialId,
    int $scannerUserId,
    string $requestedAction
): array {
    if (!in_array($requestedAction, ACCESS_ACTIONS, true)) {
        return ['success' => false, 'reason' => 'INVALID_ACTION'];
    }

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare(
            'SELECT student_id, first_name, last_name, course, year_level, status, current_status
             FROM students WHERE id = ? FOR UPDATE'
        );
        $stmt->execute([$studentId]);
        $row = $stmt->fetch();

        if (!$row) {
            $pdo->rollBack();
            return ['success' => false, 'reason' => 'STUDENT_NOT_FOUND'];
        }

        // Re-checked under the lock (the QR validation ran before the lock),
        // so a student deactivated in the meantime is still refused.
        if ($row['status'] !== 'ACTIVE') {
            $pdo->rollBack();
            return ['success' => false, 'reason' => 'STUDENT_INACTIVE'];
        }

        $student = [
            'name'       => $row['first_name'] . ' ' . $row['last_name'],
            'student_id' => $row['student_id'],
            'course'     => $row['course'],
            'year_level' => $row['year_level'],
        ];
        $currentStatus = $row['current_status'];

        if ($currentStatus !== ACCESS_REQUIRED_STATUS[$requestedAction]) {
            $pdo->rollBack();
            return [
                'success'        => false,
                'reason'         => $requestedAction === 'IN' ? 'ALREADY_IN' : 'ALREADY_OUT',
                'current_status' => $currentStatus,
                'student'        => $student,
            ];
        }

        $stmt = $pdo->prepare(
            'INSERT INTO access_transactions
                (student_id, qr_credential_id, transaction_type, timestamp, scanner_user_id, verification_result)
             VALUES (?, ?, ?, NOW(), ?, ?)'
        );
        $stmt->execute([$studentId, $qrCredentialId, $requestedAction, $scannerUserId, 'SUCCESS']);
        $transactionId = (int) $pdo->lastInsertId();

        $stmt = $pdo->prepare('UPDATE students SET current_status = ? WHERE id = ?');
        $stmt->execute([$requestedAction, $studentId]);

        $stmt = $pdo->prepare('SELECT timestamp FROM access_transactions WHERE id = ?');
        $stmt->execute([$transactionId]);
        $timestamp = $stmt->fetchColumn();

        $pdo->commit();

        return [
            'success'        => true,
            'action'         => $requestedAction,   // 'IN' or 'OUT'
            'new_status'     => $requestedAction,
            'timestamp'      => $timestamp,
            'transaction_id' => $transactionId,
            'student'        => $student,
        ];
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Access transition failed: ' . $e->getMessage());
        return ['success' => false, 'reason' => 'SYSTEM_ERROR'];
    }
}

/**
 * The single server-side entry point for every scan, whether the token came
 * from the camera or was typed in manually (scanner/verify.php calls only
 * this). Order of checks:
 *   1. selected action is exactly 'IN' or 'OUT'
 *   2. token exists / not expired / not revoked / student active
 *      (validateQrTokenForScan in includes/qr.php, unchanged)
 *   3. action vs. the student's current status, atomically
 *      (processAccessTransition)
 *
 * Returns a privacy-safe outcome array ready to be sent to the browser as
 * JSON -- see buildScanOutcome().
 */
function performScanAction(PDO $pdo, string $rawToken, mixed $action, int $scannerUserId): array
{
    if (!is_string($action) || !in_array($action, ACCESS_ACTIONS, true)) {
        return buildScanOutcome('INVALID_ACTION');
    }

    // Tokens are lowercase hex; trimming and lowercasing only forgives typing
    // noise (spaces, a phone keyboard capitalising the first letter). The
    // strict 64-hex-character format is still enforced by the validator.
    $token = strtolower(trim($rawToken));

    $validation = validateQrTokenForScan($pdo, $token);
    if (!$validation['valid']) {
        return buildScanOutcome(match ($validation['reason']) {
            'EXPIRED'          => 'TOKEN_EXPIRED',
            'REVOKED'          => 'TOKEN_REVOKED',
            'STUDENT_INACTIVE' => 'STUDENT_INACTIVE',
            default            => 'TOKEN_INVALID',   // unknown / already-used / malformed
        }, $action);
    }

    $transition = processAccessTransition(
        $pdo,
        $validation['student_id'],
        $validation['credential_id'],
        $scannerUserId,
        $action
    );

    if ($transition['success']) {
        return buildScanOutcome(
            $action === 'IN' ? 'SUCCESS_IN' : 'SUCCESS_OUT',
            $action,
            [
                'student'        => $transition['student'],
                'current_status' => $transition['new_status'],
                'timestamp'      => $transition['timestamp'],
            ]
        );
    }

    return buildScanOutcome(match ($transition['reason']) {
        'ALREADY_IN'       => 'ALREADY_IN',
        'ALREADY_OUT'      => 'ALREADY_OUT',
        'STUDENT_INACTIVE' => 'STUDENT_INACTIVE',
        'INVALID_ACTION'   => 'INVALID_ACTION',
        default            => 'SYSTEM_ERROR',
    }, $action, [
        'student'        => $transition['student'] ?? null,
        'current_status' => $transition['current_status'] ?? null,
    ]);
}

/**
 * Builds the response sent to the scanner page. Only whitelisted fields are
 * ever included, and student details appear only after a *valid* token (the
 * success and already-IN/OUT cases) -- never for invalid, expired, revoked or
 * inactive results, and never any internal/database detail.
 */
function buildScanOutcome(string $code, ?string $action = null, array $details = []): array
{
    $name = $details['student']['name'] ?? '';

    [$severity, $title, $message] = match ($code) {
        'SUCCESS_IN'       => ['success', 'ACCESS GRANTED',    'Entry recorded.'],
        'SUCCESS_OUT'      => ['success', 'ACCESS RECORDED',   'Exit recorded.'],
        'ALREADY_IN'       => ['warning', 'CANNOT SCAN IN',    $name . ' is already IN.'],
        'ALREADY_OUT'      => ['warning', 'CANNOT SCAN OUT',   $name . ' is already OUT.'],
        'TOKEN_EXPIRED'    => ['error',   'INVALID QR TOKEN',  'This QR code has expired. Ask the student to generate a new one.'],
        'TOKEN_REVOKED'    => ['error',   'INVALID QR TOKEN',  'This QR code has been revoked. Ask the student to generate a new one.'],
        'STUDENT_INACTIVE' => ['error',   'ACCESS DENIED',     'This student account is inactive.'],
        'INVALID_ACTION'   => ['error',   'NO ACTION SELECTED', 'Select SCAN IN or SCAN OUT before scanning.'],
        'SYSTEM_ERROR'     => ['error',   'SYSTEM ERROR',      'Access could not be processed. Please try again.'],
        default            => ['error',   'INVALID QR TOKEN',  'The QR token is invalid, expired, or revoked.'],
    };

    $outcome = [
        'ok'           => $severity === 'success',
        'code'         => $code,
        'severity'     => $severity,
        'title'        => $title,
        'message'      => $message,
        'action'       => $action,
        'action_label' => $action !== null ? 'SCAN ' . $action : null,
    ];

    // Student details only for the outcomes that follow a valid token.
    if (in_array($code, ['SUCCESS_IN', 'SUCCESS_OUT', 'ALREADY_IN', 'ALREADY_OUT'], true)
        && !empty($details['student'])) {
        $outcome['student'] = $details['student'];
        $outcome['current_status'] = $details['current_status'] ?? null;
    }

    if (!empty($details['timestamp'])) {
        $when = DateTime::createFromFormat('Y-m-d H:i:s', (string) $details['timestamp']);
        if ($when !== false) {
            $outcome['time'] = $when->format('g:i A');
            $outcome['date'] = $when->format('M j, Y');
        }
    }

    return $outcome;
}
