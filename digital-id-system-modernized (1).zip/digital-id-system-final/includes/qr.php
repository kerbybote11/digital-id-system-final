<?php
declare(strict_types=1);

/**
 * All QR credential logic lives here so Phase 6 (scanner) and Phase 7
 * (IN/OUT transactions) can reuse it without duplicating validation rules.
 * Nothing in this file performs an IN/OUT transition -- that is Phase 7's
 * responsibility. validateQrTokenForScan() only tells the caller whether
 * a token is currently usable.
 */

/**
 * Reads the configurable QR expiry duration (minutes) from system_config,
 * falling back to a safe default if missing or out of a sane range.
 */
function getQrExpiryMinutes(PDO $pdo): int
{
    $stmt = $pdo->prepare('SELECT config_value FROM system_config WHERE config_key = ?');
    $stmt->execute(['qr_expiry_minutes']);
    $row = $stmt->fetch();

    $minutes = $row ? (int) $row['config_value'] : 5;

    // Clamp to a sane range regardless of what's in the DB.
    if ($minutes < 1) {
        $minutes = 1;
    } elseif ($minutes > 60) {
        $minutes = 60;
    }

    return $minutes;
}

/**
 * Generates a cryptographically random raw token (never stored) and its
 * SHA-256 hash (stored). Returns [rawToken, tokenHash].
 */
function generateQrToken(): array
{
    $rawToken = bin2hex(random_bytes(32)); // 256 bits of entropy, 64 hex chars
    $tokenHash = hash('sha256', $rawToken);
    return [$rawToken, $tokenHash];
}

/**
 * Creates a new ACTIVE QR credential for a student, revoking any prior
 * ACTIVE credential(s) first (token rotation -- only one active QR per
 * student at a time). Returns the raw token, credential id, and expiry.
 * The raw token is NEVER written to the database.
 */
function createQrCredential(PDO $pdo, int $studentId): array
{
    $expiryMinutes = getQrExpiryMinutes($pdo);
    [$rawToken, $tokenHash] = generateQrToken();

    $pdo->beginTransaction();
    try {
        // Revoke any currently active credential(s) for this student so a
        // new QR never leaves an old one silently valid, and the old raw
        // token is never reachable through the new page render.
        $stmt = $pdo->prepare(
            "UPDATE qr_credentials
             SET status = 'REVOKED', revoked_at = NOW()
             WHERE student_id = ? AND status = 'ACTIVE'"
        );
        $stmt->execute([$studentId]);

        $stmt = $pdo->prepare(
            "INSERT INTO qr_credentials (student_id, token_hash, created_at, expires_at, status)
             VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL ? MINUTE), 'ACTIVE')"
        );
        $stmt->execute([$studentId, $tokenHash, $expiryMinutes]);
        $credentialId = (int) $pdo->lastInsertId();

        $pdo->commit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log('QR credential creation failed: ' . $e->getMessage());
        throw $e;
    }

    $stmt = $pdo->prepare('SELECT expires_at FROM qr_credentials WHERE id = ?');
    $stmt->execute([$credentialId]);
    $expiresAt = $stmt->fetchColumn();

    return [
        'id'         => $credentialId,
        'raw_token'  => $rawToken,
        'expires_at' => $expiresAt,
    ];
}

/**
 * Returns the student's current credential row if one exists, lazily
 * flipping ACTIVE rows that are past expiry to EXPIRED as it finds them.
 * Returns null if the student has no credential at all.
 */
function getCurrentQrForStudent(PDO $pdo, int $studentId): ?array
{
    // is_past_expiry / seconds_left are computed by MySQL against its own
    // NOW(), the same clock that wrote expires_at, so the result does not
    // depend on PHP's date.timezone matching the database time zone.
    $stmt = $pdo->prepare(
        'SELECT *,
                (expires_at < NOW()) AS is_past_expiry,
                GREATEST(TIMESTAMPDIFF(SECOND, NOW(), expires_at), 0) AS seconds_left,
                TIMESTAMPDIFF(SECOND, created_at, expires_at) AS lifetime_seconds
         FROM qr_credentials
         WHERE student_id = ?
         ORDER BY created_at DESC
         LIMIT 1'
    );
    $stmt->execute([$studentId]);
    $credential = $stmt->fetch();

    if (!$credential) {
        return null;
    }

    if ($credential['status'] === 'ACTIVE' && (int) $credential['is_past_expiry'] === 1) {
        $update = $pdo->prepare("UPDATE qr_credentials SET status = 'EXPIRED' WHERE id = ?");
        $update->execute([$credential['id']]);
        $credential['status'] = 'EXPIRED';
    }

    return $credential;
}

/**
 * Admin action: revoke a specific credential by id, regardless of who owns
 * it. Idempotent -- revoking an already-revoked/expired row is a no-op.
 */
function revokeQrCredential(PDO $pdo, int $credentialId): bool
{
    $stmt = $pdo->prepare(
        "UPDATE qr_credentials
         SET status = 'REVOKED', revoked_at = NOW()
         WHERE id = ? AND status = 'ACTIVE'"
    );
    $stmt->execute([$credentialId]);
    return $stmt->rowCount() > 0;
}

/**
 * Validation foundation for Phase 6 (scanner). Given a raw token straight
 * off a QR scan, determines whether it currently represents a usable
 * credential. Does NOT perform any IN/OUT transition or write an access
 * transaction -- that belongs to Phase 7. Returns a result array with a
 * generic 'reason' code only; callers are responsible for showing a
 * privacy-safe message (never echo student name/ID on failure).
 */
function validateQrTokenForScan(PDO $pdo, string $rawToken): array
{
    if ($rawToken === '' || !preg_match('/^[a-f0-9]{64}$/', $rawToken)) {
        return ['valid' => false, 'reason' => 'UNKNOWN_TOKEN'];
    }

    $tokenHash = hash('sha256', $rawToken);

    // Expiry is compared inside MySQL (see getCurrentQrForStudent()).
    $stmt = $pdo->prepare('SELECT *, (expires_at < NOW()) AS is_past_expiry FROM qr_credentials WHERE token_hash = ?');
    $stmt->execute([$tokenHash]);
    $credential = $stmt->fetch();

    if (!$credential) {
        return ['valid' => false, 'reason' => 'UNKNOWN_TOKEN'];
    }

    if ($credential['status'] === 'ACTIVE' && (int) $credential['is_past_expiry'] === 1) {
        $update = $pdo->prepare("UPDATE qr_credentials SET status = 'EXPIRED' WHERE id = ?");
        $update->execute([$credential['id']]);
        $credential['status'] = 'EXPIRED';
    }

    if ($credential['status'] === 'REVOKED') {
        return ['valid' => false, 'reason' => 'REVOKED'];
    }
    if ($credential['status'] === 'EXPIRED') {
        return ['valid' => false, 'reason' => 'EXPIRED'];
    }
    if ($credential['status'] === 'USED') {
        return ['valid' => false, 'reason' => 'ALREADY_USED'];
    }
    if ($credential['status'] !== 'ACTIVE') {
        return ['valid' => false, 'reason' => 'UNKNOWN_TOKEN'];
    }

    $stmt = $pdo->prepare('SELECT id, status, current_status FROM students WHERE id = ?');
    $stmt->execute([$credential['student_id']]);
    $student = $stmt->fetch();

    if (!$student || $student['status'] !== 'ACTIVE') {
        return ['valid' => false, 'reason' => 'STUDENT_INACTIVE'];
    }

    return [
        'valid'         => true,
        'credential_id' => (int) $credential['id'],
        'student_id'    => (int) $student['id'],
        'current_status'=> $student['current_status'],
    ];
}
