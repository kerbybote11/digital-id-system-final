<?php
declare(strict_types=1);

/**
 * Shared presentation helpers: page shell (sidebar, top bar, footer),
 * output escaping, icons, status badges and date formatting.
 *
 * Purely presentational -- nothing here reads or writes the database,
 * checks permissions, or changes session state. Every page still calls
 * requireRole() itself before rendering; the navigation shown below is
 * convenience only, never a security boundary.
 */

require_once __DIR__ . '/session.php';

/** HTML-escapes any value for safe output in text or attribute context. */
function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Inline SVG icon (stroke-based, 24x24). Icons are decorative
 * (aria-hidden); every control that uses one also carries a text label
 * or an accessible name.
 */
function icon(string $name, string $class = 'icon'): string
{
    static $paths = [
        'dashboard' => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
        'home'      => '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
        'users'     => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'user'      => '<circle cx="12" cy="8" r="4"/><path d="M4 21v-1a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v1"/>',
        'user-plus' => '<path d="M15 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><path d="M20 8v6M23 11h-6"/>',
        'id-card'   => '<rect x="2" y="5" width="20" height="14" rx="2"/><circle cx="8" cy="12" r="2.5"/><path d="M13 10h5M13 14h3"/>',
        'qr'        => '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM21 14v.01M14 21h.01M17.5 21H21v-3.5"/>',
        'list'      => '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
        'scan'      => '<path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/><path d="M7 12h10"/>',
        'camera'    => '<path d="M3 8a2 2 0 0 1 2-2h2l2-3h6l2 3h2a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><circle cx="12" cy="13" r="4"/>',
        'logout'    => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
        'login'     => '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/>',
        'arrow-in'  => '<path d="M17 7L7 17"/><path d="M17 17H7V7"/>',
        'arrow-out' => '<path d="M7 17L17 7"/><path d="M7 7h10v10"/>',
        'arrow-right' => '<path d="M5 12h14M13 6l6 6-6 6"/>',
        'arrow-left'  => '<path d="M19 12H5M11 18l-6-6 6-6"/>',
        'chevron-left'  => '<path d="M15 18l-6-6 6-6"/>',
        'chevron-right' => '<path d="M9 18l6-6-6-6"/>',
        'chevron-down'  => '<path d="M6 9l6 6 6-6"/>',
        'menu'      => '<path d="M3 6h18M3 12h18M3 18h18"/>',
        'x'         => '<path d="M18 6L6 18M6 6l12 12"/>',
        'search'    => '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
        'plus'      => '<path d="M12 5v14M5 12h14"/>',
        'edit'      => '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/>',
        'check-circle' => '<circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/>',
        'alert-triangle' => '<path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
        'alert-circle' => '<circle cx="12" cy="12" r="9"/><path d="M12 8v4M12 16h.01"/>',
        'info'      => '<circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/>',
        'eye'       => '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
        'eye-off'   => '<path d="M17.94 17.94A10.4 10.4 0 0 1 12 19c-6.5 0-10-7-10-7a18.5 18.5 0 0 1 5.06-5.94M9.9 5.24A9.1 9.1 0 0 1 12 5c6.5 0 10 7 10 7a18.6 18.6 0 0 1-2.16 3.19M14.12 14.12a3 3 0 1 1-4.24-4.24"/><path d="M2 2l20 20"/>',
        'clock'     => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'calendar'  => '<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
        'copy'      => '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/>',
        'refresh'   => '<path d="M21 12a9 9 0 1 1-2.64-6.36L21 8"/><path d="M21 3v5h-5"/>',
        'shield'    => '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
        'lock'      => '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
        'ban'       => '<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/>',
        'power'     => '<path d="M12 2v10"/><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/>',
        'inbox'     => '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
        'activity'  => '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
    ];

    $svg = $paths[$name] ?? $paths['info'];
    return '<svg class="' . e($class) . '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . $svg . '</svg>';
}

/** Human label for each role, used in the account menu and sidebar. */
function roleLabel(?string $role): string
{
    return match ($role) {
        'ADMIN'   => 'Administrator',
        'SCANNER' => 'Scanner Staff',
        'STUDENT' => 'Student',
        default   => 'User',
    };
}

/** Sidebar items per role. Keys are the 'active' identifiers pages pass in. */
function navItemsForRole(?string $role): array
{
    return match ($role) {
        'ADMIN' => [
            'dashboard' => ['Dashboard',      '/admin/dashboard.php',     'dashboard'],
            'students'  => ['Students',       '/admin/students.php',      'users'],
            'qr'        => ['QR Credentials', '/admin/qr-management.php', 'qr'],
            'logs'      => ['Access Logs',    '/admin/access-logs.php',   'list'],
        ],
        'STUDENT' => [
            'dashboard' => ['Dashboard',      '/student/dashboard.php',   'home'],
            'profile'   => ['My Digital ID',  '/student/profile.php',     'id-card'],
            'qr'        => ['Temporary QR',   '/student/generate-qr.php', 'qr'],
        ],
        'SCANNER' => [
            'scanner'   => ['Access Scanner', '/scanner/scanner.php',     'scan'],
        ],
        default => [],
    };
}

/** Up to two initials from a display name or username (for avatars). */
function initials(string $name): string
{
    $name = trim(preg_replace('/@.*$/', '', $name) ?? $name);
    $parts = preg_split('/[\s._\-]+/', $name, -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $letters = '';
    // Only parts that start with a letter (so "ana_54243" gives "A", not "A5").
    $parts = array_values(array_filter($parts, static fn ($p) => preg_match('/^\p{L}/u', $p) === 1));
    foreach (array_slice($parts, 0, 2) as $part) {
        $letters .= mb_strtoupper(mb_substr($part, 0, 1));
    }
    return $letters !== '' ? $letters : 'U';
}

/**
 * Formats a MySQL DATETIME ("Y-m-d H:i:s") for display without changing
 * its value or time zone. Returns the raw string unchanged if it can't
 * be parsed, so nothing is ever silently hidden.
 */
function formatDateTime(?string $value, string $format = 'M j, Y g:i A'): string
{
    if ($value === null || $value === '') {
        return '—';
    }
    $dt = DateTime::createFromFormat('Y-m-d H:i:s', $value);
    return $dt ? $dt->format($format) : $value;
}

/** <time> element with a two-line date / time presentation for tables. */
function timeCell(?string $value): string
{
    if ($value === null || $value === '') {
        return '&mdash;';
    }
    $dt = DateTime::createFromFormat('Y-m-d H:i:s', $value);
    if (!$dt) {
        return e($value);
    }
    return '<time datetime="' . e($dt->format('Y-m-d\TH:i:s')) . '">'
        . '<span class="cell-primary">' . e($dt->format('M j, Y')) . '</span>'
        . '<span class="cell-secondary">' . e($dt->format('g:i:s A')) . '</span></time>';
}

/** IN / OUT access-direction badge (text + colour + dot, never colour alone). */
function accessBadge(?string $status): string
{
    return match ($status) {
        'IN'    => '<span class="badge badge-in" title="Inside campus">IN</span>',
        'OUT'   => '<span class="badge badge-out" title="Outside campus">OUT</span>',
        default => '<span class="badge badge-neutral">' . e($status ?? 'Unknown') . '</span>',
    };
}

/** ACTIVE / INACTIVE account badge. */
function accountStatusBadge(?string $status): string
{
    return match ($status) {
        'ACTIVE'   => '<span class="badge badge-success">Active</span>',
        'INACTIVE' => '<span class="badge badge-neutral">Inactive</span>',
        default    => '<span class="badge badge-neutral">' . e($status ?? 'Unknown') . '</span>',
    };
}

/** QR credential status badge. */
function qrStatusBadge(string $status): string
{
    return match ($status) {
        'ACTIVE'  => '<span class="badge badge-success">Active</span>',
        'EXPIRED' => '<span class="badge badge-warning">Expired</span>',
        'EXPIRED (pending sync)' => '<span class="badge badge-warning" title="Past its expiry time; the stored status updates the next time this credential is checked.">Expired</span>',
        'REVOKED' => '<span class="badge badge-danger">Revoked</span>',
        'USED'    => '<span class="badge badge-neutral">Used</span>',
        default   => '<span class="badge badge-neutral">' . e($status) . '</span>',
    };
}

/**
 * Alert box. $messages may be a single string or a list (rendered as a
 * bulleted list under the title).
 */
function renderAlert(string $type, string|array $messages, string $title = '', bool $dismissible = false): string
{
    $iconName = match ($type) {
        'success' => 'check-circle',
        'error'   => 'alert-circle',
        'warning' => 'alert-triangle',
        default   => 'info',
    };
    $role = $type === 'error' ? 'alert' : 'status';
    $html = '<div class="alert alert-' . e($type) . '" role="' . $role . '">' . icon($iconName) . '<div class="alert-body">';
    if ($title !== '') {
        $html .= '<p class="alert-title">' . e($title) . '</p>';
    }
    if (is_array($messages)) {
        if (count($messages) === 1 && $title === '') {
            $html .= '<p>' . e(reset($messages)) . '</p>';
        } else {
            $html .= '<ul>';
            foreach ($messages as $m) {
                $html .= '<li>' . e($m) . '</li>';
            }
            $html .= '</ul>';
        }
    } else {
        $html .= '<p>' . e($messages) . '</p>';
    }
    $html .= '</div>';
    if ($dismissible) {
        $html .= '<button type="button" class="alert-dismiss" data-dismiss-alert aria-label="Dismiss message">' . icon('x', 'icon icon-sm') . '</button>';
    }
    return $html . '</div>';
}

/** Empty-state block for tables and panels with no data. */
function renderEmptyState(string $title, string $message, string $iconName = 'inbox', string $actionHtml = ''): string
{
    return '<div class="empty-state"><div class="empty-state-icon">' . icon($iconName, 'icon icon-lg') . '</div>'
        . '<h3>' . e($title) . '</h3><p>' . e($message) . '</p>' . $actionHtml . '</div>';
}

/**
 * Opens the authenticated app shell: <head>, sidebar, top bar, <main>.
 *
 * Options:
 *   active   string  key from navItemsForRole() to highlight
 *   subtitle string  short line under the page title
 */
function renderPageStart(string $title, array $options = []): void
{
    $role     = currentRole();
    $username = (string) ($_SESSION['username'] ?? '');
    $active   = $options['active'] ?? '';
    $subtitle = $options['subtitle'] ?? '';
    $items    = navItemsForRole($role);
    $portal   = match ($role) {
        'ADMIN'   => 'Admin Portal',
        'STUDENT' => 'Student Portal',
        'SCANNER' => 'Scanner Portal',
        default   => 'Portal',
    };
    $home = $role !== null ? dashboardPathForRole($role) : url('/auth/login.php');
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#1e40af">
    <title><?= e($title) ?> · Digital ID System</title>
    <link rel="stylesheet" href="<?= e(asset('/assets/css/style.css')) ?>">
</head>
<body class="app-body">
<a class="skip-link" href="#main">Skip to main content</a>
<div class="app-shell">
    <aside class="sidebar" id="app-sidebar" aria-label="Main navigation">
        <div class="sidebar-head">
            <a class="sidebar-brand" href="<?= e($home) ?>">
                <span class="brand-mark"><?= icon('id-card') ?></span>
                <span class="brand-text"><strong>Digital ID</strong><small><?= e($portal) ?></small></span>
            </a>
            <button type="button" class="btn-icon sidebar-close" data-nav-close aria-label="Close navigation"><?= icon('x') ?></button>
        </div>

        <p class="nav-section-label">Menu</p>
        <nav>
            <ul class="nav-list">
                <?php foreach ($items as $key => [$label, $path, $iconName]): ?>
                    <li>
                        <a class="nav-link<?= $key === $active ? ' is-active' : '' ?>" href="<?= e(url($path)) ?>"<?= $key === $active ? ' aria-current="page"' : '' ?>>
                            <?= icon($iconName) ?><span><?= e($label) ?></span>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <div class="sidebar-footer">
            <ul class="nav-list">
                <li><a class="nav-link" href="<?= e(url('/auth/logout.php')) ?>"><?= icon('logout') ?><span>Log out</span></a></li>
            </ul>
        </div>
    </aside>
    <div class="sidebar-backdrop" data-nav-close hidden></div>

    <div class="app-main">
        <header class="topbar">
            <button type="button" class="btn-icon topbar-menu" data-nav-toggle aria-controls="app-sidebar" aria-expanded="false" aria-label="Open navigation"><?= icon('menu') ?></button>
            <div class="topbar-title">
                <h1 class="page-title"><?= e($title) ?></h1>
                <?php if ($subtitle !== ''): ?><p class="page-subtitle"><?= e($subtitle) ?></p><?php endif; ?>
            </div>
            <details class="account-menu">
                <summary aria-label="Account menu for <?= e($username) ?>">
                    <span class="avatar" aria-hidden="true"><?= e(initials($username)) ?></span>
                    <span class="account-name"><span><?= e($username) ?></span><small><?= e(roleLabel($role)) ?></small></span>
                    <?= icon('chevron-down', 'icon icon-sm chevron') ?>
                </summary>
                <div class="account-dropdown">
                    <div class="account-dropdown-head">
                        <p>Signed in as</p>
                        <strong><?= e($username) ?></strong>
                        <p><?= e(roleLabel($role)) ?></p>
                    </div>
                    <a class="menu-item menu-item-danger" href="<?= e(url('/auth/logout.php')) ?>"><?= icon('logout') ?>Log out</a>
                </div>
            </details>
        </header>

        <main id="main" class="content" tabindex="-1">
    <?php
}

/**
 * Closes the app shell and loads scripts. $scripts are app-relative paths
 * loaded after the shared app.js.
 */
function renderPageEnd(array $scripts = []): void
{
    ?>
        </main>
        <footer class="app-footer">
            &copy; <?= e(date('Y')) ?> Digital ID System &middot; Student Access Verification
        </footer>
    </div>
</div>

<dialog class="modal" id="confirm-dialog" aria-labelledby="confirm-title" aria-describedby="confirm-message">
    <form method="dialog" class="modal-content">
        <div class="modal-icon"><?= icon('alert-triangle') ?></div>
        <h2 class="modal-title" id="confirm-title">Are you sure?</h2>
        <p class="modal-message" id="confirm-message"></p>
        <div class="modal-actions">
            <button type="submit" value="cancel" class="btn btn-secondary" id="confirm-cancel">Cancel</button>
            <button type="submit" value="confirm" class="btn btn-danger" id="confirm-ok">Confirm</button>
        </div>
    </form>
</dialog>

<script src="<?= e(asset('/assets/js/app.js')) ?>"></script>
<?php foreach ($scripts as $src): ?>
<script src="<?= e(asset($src)) ?>"></script>
<?php endforeach; ?>
</body>
</html>
    <?php
}

/**
 * Assigns each validation message from the student forms to the field it
 * describes, so it can be shown inline next to that field. Messages come
 * verbatim from includes/validation.php and the uniqueness checks; any
 * message that matches no field is returned under '_form'.
 */
function mapStudentFormErrors(array $errors): array
{
    $prefixes = [
        'student_id'    => ['Student ID', 'That Student ID'],
        'first_name'    => ['First name'],
        'last_name'     => ['Last name'],
        'course'        => ['Course'],
        'year_level'    => ['Year level'],
        'username'      => ['Username', 'That username'],
        'temp_password' => ['Temporary password'],
    ];
    $mapped = [];
    foreach ($errors as $message) {
        $field = '_form';
        foreach ($prefixes as $name => $starts) {
            foreach ($starts as $start) {
                if (str_starts_with($message, $start)) {
                    $field = $name;
                    break 2;
                }
            }
        }
        $mapped[$field][] = $message;
    }
    return $mapped;
}

/**
 * Renders one labelled text input with optional hint and inline error.
 * Keys: name, label, value, type, required, maxlength, minlength, hint,
 *       errors (string[]), autocomplete, list, span2, placeholder.
 */
function formField(array $f): string
{
    $name     = $f['name'];
    $id       = $f['id'] ?? $name;
    $errors   = $f['errors'] ?? [];
    $hintId   = $id . '-hint';
    $errorId  = $id . '-error';
    $describe = [];
    if (!empty($f['hint']))  { $describe[] = $hintId; }
    if ($errors)             { $describe[] = $errorId; }

    $attrs = ' class="form-control" type="' . e($f['type'] ?? 'text') . '" id="' . e($id) . '" name="' . e($name) . '"';
    if (array_key_exists('value', $f)) { $attrs .= ' value="' . e($f['value']) . '"'; }
    if (!empty($f['required']))      { $attrs .= ' required'; }
    if (!empty($f['maxlength']))     { $attrs .= ' maxlength="' . (int) $f['maxlength'] . '"'; }
    if (!empty($f['minlength']))     { $attrs .= ' minlength="' . (int) $f['minlength'] . '"'; }
    if (!empty($f['autocomplete']))  { $attrs .= ' autocomplete="' . e($f['autocomplete']) . '"'; }
    if (!empty($f['list']))          { $attrs .= ' list="' . e($f['list']) . '"'; }
    if (!empty($f['placeholder']))   { $attrs .= ' placeholder="' . e($f['placeholder']) . '"'; }
    if (!empty($f['spellcheck_off'])) { $attrs .= ' autocapitalize="none" spellcheck="false"'; }
    if ($errors)                     { $attrs .= ' aria-invalid="true"'; }
    if ($describe)                   { $attrs .= ' aria-describedby="' . e(implode(' ', $describe)) . '"'; }

    $isPassword = ($f['type'] ?? '') === 'password';

    $html = '<div class="form-group' . (!empty($f['span2']) ? ' span-2' : '') . '">';
    $html .= '<label class="form-label" for="' . e($id) . '">' . e($f['label'])
          . (!empty($f['required']) ? '<span class="req" aria-hidden="true">*</span>' : '') . '</label>';
    if ($isPassword) {
        $html .= '<div class="input-group has-action"><input' . $attrs . '>'
              . '<button type="button" class="input-action" data-password-toggle aria-controls="' . e($id) . '"'
              . ' aria-label="Show password" aria-pressed="false" hidden>'
              . '<span data-icon="show">' . icon('eye') . '</span><span data-icon="hide" hidden>' . icon('eye-off') . '</span>'
              . '</button></div>';
    } else {
        $html .= '<input' . $attrs . '>';
    }
    if (!empty($f['hint'])) {
        $html .= '<p class="form-hint" id="' . e($hintId) . '">' . e($f['hint']) . '</p>';
    }
    if ($errors) {
        $html .= '<p class="form-error" id="' . e($errorId) . '">' . e(implode(' ', $errors)) . '</p>';
    }
    return $html . '</div>';
}
