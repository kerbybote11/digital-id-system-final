<?php
declare(strict_types=1);

/**
 * Base-path handling (Phase 10 defect fix): the project doesn't have to
 * live at the web server's root -- it can be installed as a subdirectory
 * (e.g. htdocs/digital-id-system-final/). Every hardcoded absolute path
 * like "/admin/dashboard.php" in this codebase previously assumed root
 * installation and would break under a subdirectory install. BASE_URL is
 * auto-detected here (once, centrally) by comparing the real filesystem
 * path of the project root (this file's parent directory) against the
 * server's document root -- no manual per-install configuration needed.
 * url($path) is then used everywhere a page previously hardcoded a
 * leading-slash path, so every link/redirect/asset/form-action resolves
 * correctly regardless of which subdirectory the project sits in.
 */
if (!defined('BASE_URL')) {
    $normalize = static fn ($p) => is_string($p) && $p !== '' ? rtrim(str_replace('\\', '/', $p), '/') : '';

    $projectRoot = $normalize(realpath(__DIR__ . '/..'));
    $basePath = null;

    // 1) Preferred: derive the URL prefix from the script being executed.
    //    If SCRIPT_FILENAME is <projectRoot>/auth/login.php and SCRIPT_NAME is
    //    /my-folder/auth/login.php, the base is /my-folder. This also works
    //    for Apache Alias / virtual-host setups and Windows drive-letter or
    //    case differences, where the document-root comparison below fails.
    $scriptFile = $normalize(realpath((string) ($_SERVER['SCRIPT_FILENAME'] ?? '')) ?: '');
    $scriptName = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? ''));
    if ($projectRoot !== '' && $scriptFile !== '' && $scriptName !== ''
        && stripos($scriptFile, $projectRoot . '/') === 0) {
        $relative = substr($scriptFile, strlen($projectRoot));          // e.g. /auth/login.php
        if (strlen($scriptName) >= strlen($relative)
            && strcasecmp(substr($scriptName, -strlen($relative)), $relative) === 0) {
            $basePath = rtrim(substr($scriptName, 0, -strlen($relative)), '/');
        }
    }

    // 2) Fallback (original method): project root relative to DOCUMENT_ROOT,
    //    compared case-insensitively for Windows paths.
    if ($basePath === null) {
        $basePath = '';
        $docRoot = $normalize(realpath((string) ($_SERVER['DOCUMENT_ROOT'] ?? '')) ?: '');
        if ($projectRoot !== '' && $docRoot !== '' && stripos($projectRoot, $docRoot) === 0) {
            $basePath = substr($projectRoot, strlen($docRoot));
        }
    }

    // Root installs (basePath === '') are unaffected: url('/x') still
    // returns '/x' exactly as every hardcoded path already did.
    define('BASE_URL', $basePath);
}

/**
 * Prepends the auto-detected project base path to an app-relative path.
 * Use this for every internal link, form action, asset reference, and
 * redirect instead of a hardcoded leading-slash string.
 */
function url(string $path): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

/**
 * url() for static files (CSS/JS), with the file's modification time
 * appended (?v=...) so browsers always load the current version after an
 * update instead of a stale cached copy.
 */
function asset(string $path): string
{
    $file = __DIR__ . '/../' . ltrim($path, '/');
    $version = is_file($file) ? (string) filemtime($file) : '1';
    return url($path) . '?v=' . $version;
}

/**
 * Phase 9 security fix (Finding #1): global safety net so an uncaught
 * exception or fatal error NEVER reaches the browser with internal
 * details (SQL text, file paths, stack traces) -- regardless of the
 * server's display_errors setting. This is included first, before any
 * DB connection or query runs anywhere in the app, since session.php is
 * the universal first require_once in every entry-point file.
 * Full internal detail is still logged server-side via error_log().
 */
set_exception_handler(function (Throwable $e) {
    error_log('Uncaught exception: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) {
        http_response_code(500);
    }
    echo 'A system error occurred. Please try again later.';
});
ini_set('display_errors', '0');

/**
 * Starts a hardened session. Include this at the top of every protected page
 * (and on login.php) before any output is sent.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_httponly' => true,
        'cookie_samesite' => 'Lax',
        // 'cookie_secure' => true, // enable once served over HTTPS
    ]);
}

/**
 * Redirects to login if no user is authenticated. Call at the top of any
 * page that requires a logged-in user, regardless of role.
 */
function requireLogin(): void
{
    if (empty($_SESSION['user_id'])) {
        header('Location: ' . url('/auth/login.php'));
        exit;
    }
}

/**
 * Redirects to login if not authenticated, or shows 403 if the logged-in
 * user's role is not one of the allowed roles.
 * Usage: requireRole('ADMIN'); or requireRole('ADMIN', 'SCANNER');
 */
function requireRole(string ...$allowedRoles): void
{
    requireLogin();

    if (!in_array($_SESSION['role'], $allowedRoles, true)) {
        http_response_code(403);
        die('Access denied. You do not have permission to view this page.');
    }
}

/**
 * Sends a JSON response and ends the request. Used by AJAX endpoints
 * (scanner/verify.php) where redirecting to a login page or printing plain
 * text would break the calling JavaScript.
 */
function jsonResponse(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/**
 * Same authorization rule as requireRole(), but answers with a JSON error
 * (401 not logged in / 403 wrong role) instead of a redirect or plain text.
 * The check is still enforced on the server for every request.
 */
function requireRoleJson(string ...$allowedRoles): void
{
    if (empty($_SESSION['user_id'])) {
        jsonResponse(401, [
            'ok' => false, 'code' => 'AUTH_REQUIRED', 'severity' => 'error',
            'title' => 'SESSION EXPIRED',
            'message' => 'Your session has expired. Reload the page and log in again.',
        ]);
    }

    if (!in_array($_SESSION['role'] ?? null, $allowedRoles, true)) {
        jsonResponse(403, [
            'ok' => false, 'code' => 'FORBIDDEN', 'severity' => 'error',
            'title' => 'ACCESS DENIED',
            'message' => 'You do not have permission to use the scanner.',
        ]);
    }
}

function currentUserId(): ?int
{
    return isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null;
}

function currentRole(): ?string
{
    return $_SESSION['role'] ?? null;
}

/**
 * Maps a role to its default dashboard path.
 */
function dashboardPathForRole(string $role): string
{
    $map = [
        'ADMIN'   => '/admin/dashboard.php',
        'SCANNER' => '/scanner/scanner.php',
        'STUDENT' => '/student/dashboard.php',
    ];

    return url($map[$role] ?? '/auth/login.php');
}
