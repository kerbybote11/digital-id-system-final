<?php
declare(strict_types=1);

/**
 * Returns the current CSRF token, generating one if it doesn't exist yet.
 * Call this when rendering any form: value="<?= htmlspecialchars(csrfToken()) ?>"
 */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

/**
 * Verifies a submitted CSRF token against the one stored in the session.
 * Use a timing-safe comparison to avoid leaking information via timing.
 */
function verifyCsrfToken(?string $submittedToken): bool
{
    return !empty($_SESSION['csrf_token'])
        && !empty($submittedToken)
        && hash_equals($_SESSION['csrf_token'], $submittedToken);
}
