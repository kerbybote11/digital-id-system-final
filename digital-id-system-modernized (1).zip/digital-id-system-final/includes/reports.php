<?php
declare(strict_types=1);

/**
 * Read-only reporting/monitoring helpers for the admin dashboard and
 * access log. Nothing here writes to the database, changes QR status, or
 * touches students.current_status -- Phase 7's transition logic is never
 * called or duplicated here; this file only reads what it already wrote.
 */

/**
 * Summary counts for the dashboard widgets.
 */
function getDashboardStats(PDO $pdo): array
{
    $totalStudents    = (int) $pdo->query('SELECT COUNT(*) FROM students')->fetchColumn();
    $activeStudents   = (int) $pdo->query("SELECT COUNT(*) FROM students WHERE status = 'ACTIVE'")->fetchColumn();
    $inactiveStudents = (int) $pdo->query("SELECT COUNT(*) FROM students WHERE status = 'INACTIVE'")->fetchColumn();
    $currentlyIn      = (int) $pdo->query("SELECT COUNT(*) FROM students WHERE current_status = 'IN'")->fetchColumn();
    $currentlyOut     = (int) $pdo->query("SELECT COUNT(*) FROM students WHERE current_status = 'OUT'")->fetchColumn();

    $todayIn = (int) $pdo->query(
        "SELECT COUNT(*) FROM access_transactions
         WHERE transaction_type = 'IN' AND DATE(timestamp) = CURDATE()"
    )->fetchColumn();

    $todayOut = (int) $pdo->query(
        "SELECT COUNT(*) FROM access_transactions
         WHERE transaction_type = 'OUT' AND DATE(timestamp) = CURDATE()"
    )->fetchColumn();

    return [
        'total_students'    => $totalStudents,
        'active_students'   => $activeStudents,
        'inactive_students' => $inactiveStudents,
        'currently_in'      => $currentlyIn,
        'currently_out'     => $currentlyOut,
        'today_in'          => $todayIn,
        'today_out'         => $todayOut,
    ];
}

/**
 * Most recent N access transactions, for the dashboard's quick view.
 * Never selects token_hash or any QR credential content -- only its id,
 * shown purely as an internal reference number.
 */
function getRecentTransactions(PDO $pdo, int $limit = 10): array
{
    $limit = max(1, min($limit, 50));

    $stmt = $pdo->prepare(
        "SELECT at.id, at.transaction_type, at.timestamp, at.qr_credential_id,
                s.student_id, s.first_name, s.last_name,
                u.username AS scanner_username
         FROM access_transactions at
         JOIN students s ON s.id = at.student_id
         JOIN users u ON u.id = at.scanner_user_id
         ORDER BY at.timestamp DESC
         LIMIT $limit"
    );
    // $limit is validated/clamped above, not user-supplied raw SQL text,
    // so it is safe to inline here (LIMIT does not support bound
    // parameters consistently across all PDO driver configurations).
    $stmt->execute();

    return $stmt->fetchAll();
}

/**
 * Validated filter set for the access log. Call this on raw $_GET input
 * before passing filters into searchAccessTransactions().
 */
function sanitizeAccessLogFilters(array $input): array
{
    $search = trim((string) ($input['q'] ?? ''));

    $type = $input['type'] ?? '';
    $type = in_array($type, ['IN', 'OUT'], true) ? $type : '';

    $dateFrom = (string) ($input['date_from'] ?? '');
    $dateFrom = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom) ? $dateFrom : '';

    $dateTo = (string) ($input['date_to'] ?? '');
    $dateTo = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo) ? $dateTo : '';

    $page = (int) ($input['page'] ?? 1);
    $page = max(1, $page);

    return [
        'search'    => $search,
        'type'      => $type,
        'date_from' => $dateFrom,
        'date_to'   => $dateTo,
        'page'      => $page,
    ];
}

/**
 * Server-side search/filter/paginate over access_transactions. Returns
 * ['rows' => [...], 'total_count' => int, 'total_pages' => int, 'page' => int].
 * All filter values are bound as parameters -- never concatenated into SQL.
 */
function searchAccessTransactions(PDO $pdo, array $filters, int $pageSize = 20): array
{
    $pageSize = max(1, min($pageSize, 100));
    $page = max(1, (int) ($filters['page'] ?? 1));

    $whereClauses = [];
    $params = [];

    if ($filters['search'] !== '') {
        // Distinct placeholder names: a named parameter used more than once
        // fails with native prepares (PDO::ATTR_EMULATE_PREPARES = false).
        $whereClauses[] = '(s.student_id LIKE :search1 OR s.first_name LIKE :search2 OR s.last_name LIKE :search3)';
        $like = '%' . $filters['search'] . '%';
        $params[':search1'] = $params[':search2'] = $params[':search3'] = $like;
    }

    if ($filters['type'] !== '') {
        $whereClauses[] = 'at.transaction_type = :type';
        $params[':type'] = $filters['type'];
    }

    if ($filters['date_from'] !== '') {
        $whereClauses[] = 'DATE(at.timestamp) >= :date_from';
        $params[':date_from'] = $filters['date_from'];
    }

    if ($filters['date_to'] !== '') {
        $whereClauses[] = 'DATE(at.timestamp) <= :date_to';
        $params[':date_to'] = $filters['date_to'];
    }

    $whereSql = '';
    if (!empty($whereClauses)) {
        $whereSql = 'WHERE ' . implode(' AND ', $whereClauses);
    }

    // Total count for pagination (same filters, no LIMIT).
    $countSql = "SELECT COUNT(*)
                 FROM access_transactions at
                 JOIN students s ON s.id = at.student_id
                 JOIN users u ON u.id = at.scanner_user_id
                 {$whereSql}";
    $countStmt = $pdo->prepare($countSql);
    $countStmt->execute($params);
    $totalCount = (int) $countStmt->fetchColumn();

    $totalPages = (int) max(1, ceil($totalCount / $pageSize));
    $page = min($page, $totalPages);
    $offset = ($page - 1) * $pageSize;

    $dataSql = "SELECT at.id, at.transaction_type, at.timestamp, at.qr_credential_id,
                       s.student_id, s.first_name, s.last_name,
                       u.username AS scanner_username
                FROM access_transactions at
                JOIN students s ON s.id = at.student_id
                JOIN users u ON u.id = at.scanner_user_id
                {$whereSql}
                ORDER BY at.timestamp DESC
                LIMIT {$pageSize} OFFSET {$offset}";
    // $pageSize and $offset are integers computed/clamped above, not raw
    // user input, so inlining them here is safe; all real filter VALUES
    // above are still bound via named parameters.
    $dataStmt = $pdo->prepare($dataSql);
    $dataStmt->execute($params);
    $rows = $dataStmt->fetchAll();

    return [
        'rows'        => $rows,
        'total_count' => $totalCount,
        'total_pages' => $totalPages,
        'page'        => $page,
    ];
}
