<?php
declare(strict_types=1);

/**
 * Each validator returns an error message string, or '' if the value is valid.
 * Kept dependency-free (no DB access here) so these can be unit-tested in isolation.
 * Uniqueness checks (student_id / username already taken) are done separately
 * against the database where the record is actually being saved.
 */

function validateStudentIdFormat(string $value): string
{
    $value = trim($value);
    if ($value === '') {
        return 'Student ID is required.';
    }
    if (mb_strlen($value) > 30) {
        return 'Student ID must be 30 characters or fewer.';
    }
    if (!preg_match('/^[A-Za-z0-9\-]+$/', $value)) {
        return 'Student ID may only contain letters, numbers, and hyphens.';
    }
    return '';
}

function validateName(string $value, string $label): string
{
    $value = trim($value);
    if ($value === '') {
        return "{$label} is required.";
    }
    if (mb_strlen($value) > 100) {
        return "{$label} must be 100 characters or fewer.";
    }
    if (!preg_match("/^[A-Za-z\s'\-]+$/u", $value)) {
        return "{$label} may only contain letters, spaces, hyphens, and apostrophes.";
    }
    return '';
}

function validateCourse(string $value): string
{
    $value = trim($value);
    if ($value === '') {
        return 'Course is required.';
    }
    if (mb_strlen($value) > 100) {
        return 'Course must be 100 characters or fewer.';
    }
    return '';
}

function validateYearLevel(string $value): string
{
    $value = trim($value);
    if ($value === '') {
        return 'Year level is required.';
    }
    if (mb_strlen($value) > 20) {
        return 'Year level must be 20 characters or fewer.';
    }
    return '';
}

function validateUsernameFormat(string $value): string
{
    $value = trim($value);
    if ($value === '') {
        return 'Username is required.';
    }
    if (mb_strlen($value) < 3 || mb_strlen($value) > 50) {
        return 'Username must be between 3 and 50 characters.';
    }
    if (!preg_match('/^[A-Za-z0-9_]+$/', $value)) {
        return 'Username may only contain letters, numbers, and underscores.';
    }
    return '';
}

function validateTemporaryPassword(string $value): string
{
    if (mb_strlen($value) < 8) {
        return 'Temporary password must be at least 8 characters.';
    }
    return '';
}
