<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/session.php';

if (empty($_SESSION['user_id'])) {
    header('Location: ' . url('/auth/login.php'));
    exit;
}

header('Location: ' . dashboardPathForRole($_SESSION['role']));
exit;
