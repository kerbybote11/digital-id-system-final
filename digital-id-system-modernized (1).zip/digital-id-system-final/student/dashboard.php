<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/qr.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../config/database.php';

requireRole('STUDENT');

$pdo = getDBConnection();

// Scoped to the logged-in user only -- no client-supplied student
// identifier is ever accepted here, consistent with student/profile.php
// and student/generate-qr.php.
$stmt = $pdo->prepare(
    'SELECT id, student_id, first_name, last_name, course, year_level, status, current_status
     FROM students
     WHERE user_id = ?'
);
$stmt->execute([currentUserId()]);
$student = $stmt->fetch();

if (!$student) {
    http_response_code(404);
    die('Student profile not found.');
}

// Read-only QR summary (same helper generate-qr.php uses; it only flips a
// past-expiry ACTIVE row to EXPIRED, exactly as that page already does).
$qr = getCurrentQrForStudent($pdo, (int) $student['id']);
$qrActive = $qr !== null && $qr['status'] === 'ACTIVE';
$isActiveAccount = $student['status'] === 'ACTIVE';
$fullName = $student['first_name'] . ' ' . $student['last_name'];

renderPageStart('Dashboard', [
    'active'   => 'dashboard',
    'subtitle' => 'Your digital ID and campus access',
]);
?>
<div class="stack-lg">
    <section class="welcome-card" aria-labelledby="welcome-heading">
        <div>
            <h2 id="welcome-heading">Welcome, <?= e($student['first_name']) ?>!</h2>
            <p><?= e($student['course']) ?> &middot; <?= e($student['year_level']) ?> &middot; <span class="mono"><?= e($student['student_id']) ?></span></p>
        </div>
        <?php if ($isActiveAccount): ?>
            <a class="btn btn-primary btn-lg" href="<?= e(url('/student/generate-qr.php')) ?>"><?= icon('qr') ?><?= $qrActive ? 'View my QR code' : 'Generate QR code' ?></a>
        <?php endif; ?>
    </section>

    <?php if (!$isActiveAccount): ?>
        <?= renderAlert('warning', 'Your account is inactive, so you can’t generate QR codes. Please contact an administrator.', 'Account inactive') ?>
    <?php endif; ?>

    <div class="grid grid-2">
        <section class="card status-tile" aria-label="Current access status">
            <span class="stat-icon <?= $student['current_status'] === 'IN' ? 'tone-success' : 'tone-warning' ?>">
                <?= icon($student['current_status'] === 'IN' ? 'arrow-in' : 'arrow-out', 'icon icon-lg') ?>
            </span>
            <div>
                <p class="status-tile-label">Current access status</p>
                <p class="status-tile-value">
                    <?= accessBadge($student['current_status']) ?>
                    <span><?= $student['current_status'] === 'IN' ? 'Inside campus' : 'Outside campus' ?></span>
                </p>
            </div>
        </section>

        <section class="card status-tile" aria-label="Temporary QR status">
            <span class="stat-icon <?= $qrActive ? '' : 'tone-neutral' ?>"><?= icon('qr', 'icon icon-lg') ?></span>
            <div>
                <p class="status-tile-label">Temporary QR</p>
                <p class="status-tile-value">
                    <?php if ($qrActive): ?>
                        <span class="badge badge-success">Active</span>
                        <span class="text-sm muted">until <?= e(formatDateTime($qr['expires_at'], 'g:i A')) ?></span>
                    <?php elseif ($qr !== null): ?>
                        <?= qrStatusBadge($qr['status']) ?>
                        <span class="text-sm muted">Generate a new one when needed</span>
                    <?php else: ?>
                        <span class="badge badge-neutral">None yet</span>
                    <?php endif; ?>
                </p>
            </div>
        </section>
    </div>

    <div class="grid grid-2">
        <section class="card" aria-labelledby="profile-heading">
            <div class="card-header">
                <div>
                    <h2 id="profile-heading">My details</h2>
                    <p>As recorded by the school.</p>
                </div>
                <a class="btn btn-secondary btn-sm" href="<?= e(url('/student/profile.php')) ?>"><?= icon('id-card', 'icon icon-sm') ?>My Digital ID</a>
            </div>
            <div class="card-body">
                <dl class="detail-list">
                    <dt>Name</dt><dd><?= e($fullName) ?></dd>
                    <dt>Student ID</dt><dd class="mono"><?= e($student['student_id']) ?></dd>
                    <dt>Course</dt><dd><?= e($student['course']) ?></dd>
                    <dt>Year level</dt><dd><?= e($student['year_level']) ?></dd>
                    <dt>Account status</dt><dd><?= accountStatusBadge($student['status']) ?></dd>
                </dl>
            </div>
        </section>

        <section class="card" aria-labelledby="how-heading">
            <div class="card-header">
                <div>
                    <h2 id="how-heading">How campus access works</h2>
                    <p>Three quick steps at the gate.</p>
                </div>
            </div>
            <div class="card-body">
                <ol class="steps-list">
                    <li><span><strong>Generate a temporary QR</strong>Open <em>Temporary QR</em> shortly before you reach the entrance.</span></li>
                    <li><span><strong>Show it to the scanner staff</strong>They scan it to record your entry (IN) or exit (OUT).</span></li>
                    <li><span><strong>Keep it private</strong>The code expires automatically. Never share a screenshot of it.</span></li>
                </ol>
            </div>
        </section>
    </div>
</div>
<?php renderPageEnd(); ?>
