<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../config/database.php';

requireRole('STUDENT');

$pdo = getDBConnection();

// Always scoped to the logged-in user's own id -- no client-supplied
// student identifier is ever accepted on this page.
$stmt = $pdo->prepare(
    'SELECT student_id, first_name, last_name, course, year_level, status, current_status
     FROM students
     WHERE user_id = ?'
);
$stmt->execute([currentUserId()]);
$student = $stmt->fetch();

if (!$student) {
    http_response_code(404);
    die('Student profile not found.');
}

$fullName = $student['first_name'] . ' ' . $student['last_name'];

renderPageStart('My Digital ID', [
    'active'   => 'profile',
    'subtitle' => 'Your student identification details',
]);
?>
<div class="grid grid-aside-main">
    <section aria-labelledby="idcard-heading">
        <h2 id="idcard-heading" class="sr-only">Digital ID card</h2>
        <div class="id-card">
            <div class="id-card-top">
                <span>Student Digital ID</span>
                <?= icon('id-card') ?>
            </div>
            <div class="id-card-body">
                <span class="avatar" aria-hidden="true"><?= e(initials($fullName)) ?></span>
                <div>
                    <p class="id-card-name"><?= e($fullName) ?></p>
                    <p class="id-card-id"><?= e($student['student_id']) ?></p>
                </div>
            </div>
            <div class="id-card-foot">
                <?= accountStatusBadge($student['status']) ?>
                <?= accessBadge($student['current_status']) ?>
            </div>
        </div>
        <?php if ($student['status'] === 'ACTIVE'): ?>
            <a class="btn btn-primary btn-block mt-4" href="<?= e(url('/student/generate-qr.php')) ?>"><?= icon('qr') ?>Show my temporary QR</a>
        <?php endif; ?>
    </section>

    <section class="card" aria-labelledby="details-heading">
        <div class="card-header">
            <div>
                <h2 id="details-heading">Profile information</h2>
                <p>These details are managed by the school administrator.</p>
            </div>
        </div>
        <div class="card-body stack">
            <dl class="detail-list">
                <dt>Full name</dt><dd><?= e($fullName) ?></dd>
                <dt>Student ID</dt><dd class="mono"><?= e($student['student_id']) ?></dd>
                <dt>Course</dt><dd><?= e($student['course']) ?></dd>
                <dt>Year level</dt><dd><?= e($student['year_level']) ?></dd>
                <dt>Account status</dt><dd><?= accountStatusBadge($student['status']) ?></dd>
                <dt>Current access</dt><dd><?= accessBadge($student['current_status']) ?> <span class="text-sm muted"><?= $student['current_status'] === 'IN' ? 'Inside campus' : 'Outside campus' ?></span></dd>
            </dl>
            <div class="info-note">
                <?= icon('info') ?>
                <span>Something incorrect? Profile details can only be changed by an administrator. Please contact the registrar or system administrator to request a correction.</span>
            </div>
        </div>
    </section>
</div>
<?php renderPageEnd(); ?>
