<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/qr.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../config/database.php';

requireRole('STUDENT');

$pdo = getDBConnection();

// Scoped to the logged-in user only -- never accepts a student id from the client.
$stmt = $pdo->prepare('SELECT id, status FROM students WHERE user_id = ?');
$stmt->execute([currentUserId()]);
$student = $stmt->fetch();

if (!$student) {
    http_response_code(404);
    die('Student profile not found.');
}

if ($student['status'] !== 'ACTIVE') {
    http_response_code(403);
    die('Your account is inactive. Please contact an administrator.');
}

$error = '';

// Handle "Generate new QR" action
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        $error = 'Invalid request. Please refresh the page and try again.';
    } else {
        try {
            $result = createQrCredential($pdo, (int) $student['id']);

            // Raw token lives ONLY in the session, tied to this specific
            // credential id, so a page refresh before expiry can redisplay
            // it without ever persisting it to the database.
            $_SESSION['qr_credential_id'] = $result['id'];
            $_SESSION['qr_raw_token']     = $result['raw_token'];

            header('Location: ' . url('/student/generate-qr.php'));
            exit;
        } catch (Throwable $e) {
            $error = 'A system error occurred while generating your QR code. Please try again.';
        }
    }
}

// Determine what to display
$currentCredential = getCurrentQrForStudent($pdo, (int) $student['id']);
$displayToken = null;
$displayExpiresAt = null;

if ($currentCredential
    && $currentCredential['status'] === 'ACTIVE'
    && isset($_SESSION['qr_credential_id'], $_SESSION['qr_raw_token'])
    && $_SESSION['qr_credential_id'] === (int) $currentCredential['id']
) {
    $displayToken = $_SESSION['qr_raw_token'];
    $displayExpiresAt = $currentCredential['expires_at'];
}

// Countdown inputs computed by MySQL (see getCurrentQrForStudent()), so the
// on-screen timer doesn't depend on the browser's or PHP's time zone.
$secondsLeft = $currentCredential !== null ? (int) ($currentCredential['seconds_left'] ?? 0) : 0;
$lifetime    = $currentCredential !== null ? max(1, (int) ($currentCredential['lifetime_seconds'] ?? 0)) : 1;
$lastStatus  = $currentCredential['status'] ?? null;

renderPageStart('Temporary QR', [
    'active'   => 'qr',
    'subtitle' => 'Show this code to the scanner staff at the entrance',
]);
?>
<?php if ($error !== ''): ?>
    <div class="alert-stack"><?= renderAlert('error', $error) ?></div>
<?php endif; ?>

<div class="grid grid-main-aside">
    <?php if ($displayToken !== null): ?>
        <section class="card qr-panel" id="qr-panel" aria-labelledby="qr-heading">
            <div class="card-header">
                <div>
                    <h2 id="qr-heading">Your access QR code</h2>
                    <p>Hold your screen steady in front of the scanner.</p>
                </div>
                <span class="badge badge-success" id="qr-status-badge">Active</span>
            </div>
            <div class="card-body">
                <div class="qr-frame">
                    <div id="qr-code-container" data-qr-value="<?= e($displayToken) ?>" role="img"
                         aria-label="Your temporary access QR code"></div>
                    <div class="qr-expired-overlay" aria-hidden="true">
                        <?= icon('clock', 'icon icon-lg') ?>
                        <span>This QR code has expired</span>
                    </div>
                </div>

                <div class="countdown">
                    <span class="countdown-label"><?= icon('clock', 'icon icon-sm') ?><span id="qr-countdown-label">Expires in</span></span>
                    <span class="countdown-value" id="qr-countdown"
                          data-expires-at="<?= e($displayExpiresAt) ?>"
                          data-seconds-left="<?= $secondsLeft ?>"
                          data-lifetime="<?= $lifetime ?>">--:--</span>
                    <div class="progress" aria-hidden="true"><div class="progress-bar" id="qr-progress"></div></div>
                    <p class="sr-only" id="qr-expiry-announce" aria-live="assertive"></p>
                </div>

                <details class="token-details">
                    <summary><?= icon('chevron-right', 'icon icon-sm chevron') ?>Camera not working? Show code for manual entry</summary>
                    <!-- The same token the QR encodes, so a scanner operator can enter it
                         manually if the camera can't read the QR. Only ever shown to the
                         student it belongs to, and only while it is ACTIVE. -->
                    <div class="token-box">
                        <label class="form-label" for="qr-token-text">Token for manual entry</label>
                        <div class="token-row">
                            <input type="text" id="qr-token-text" class="token-text" readonly
                                   value="<?= e($displayToken) ?>">
                            <button type="button" class="btn btn-secondary" id="copy-token"><?= icon('copy', 'icon icon-sm') ?>Copy</button>
                        </div>
                        <span id="copy-token-note" class="copy-note" role="status"></span>
                        <p class="form-hint">Only read this to scanner staff in person. Never send it to anyone.</p>
                    </div>
                </details>
            </div>
        </section>
    <?php else: ?>
        <section class="card qr-panel" aria-labelledby="qr-heading">
            <div class="card-header">
                <div>
                    <h2 id="qr-heading">Your access QR code</h2>
                    <p>
                        <?php if ($currentCredential && $currentCredential['status'] === 'ACTIVE'): ?>
                            An active QR exists but was created in another session or device.
                        <?php elseif ($lastStatus === 'EXPIRED'): ?>
                            Your last QR code has expired.
                        <?php elseif ($lastStatus === 'REVOKED'): ?>
                            Your last QR code was revoked.
                        <?php else: ?>
                            You don’t have an active QR code yet.
                        <?php endif; ?>
                    </p>
                </div>
                <?php if ($lastStatus !== null): ?><?= qrStatusBadge($lastStatus) ?><?php endif; ?>
            </div>
            <div class="card-body">
                <div class="qr-placeholder"><?= icon('qr') ?></div>

                <?php if ($currentCredential && $currentCredential['status'] === 'ACTIVE'): ?>
                    <!-- An active credential exists in the DB, but this session doesn't hold
                         its raw token (e.g. a different device/session generated it). The
                         server never re-derives a raw token from a stored hash, so it
                         cannot be redisplayed here -- only a fresh one can be issued. -->
                    <div class="info-note">
                        <?= icon('info') ?>
                        <span>For security, a QR code can only be displayed in the session that created it. Generate a new one here — the other code will stop working.</span>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?= e(url('/student/generate-qr.php')) ?>" data-loading>
                    <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <?= icon('qr') ?><span><?= $currentCredential && $currentCredential['status'] === 'ACTIVE' ? 'Generate New QR' : 'Generate Temporary QR' ?></span>
                        <span class="spinner" aria-hidden="true"></span>
                    </button>
                </form>
            </div>
        </section>
    <?php endif; ?>

    <aside class="stack-lg">
        <?php if ($displayToken !== null): ?>
            <section class="card" aria-labelledby="regen-heading">
                <div class="card-header">
                    <div>
                        <h2 id="regen-heading">Need a fresh code?</h2>
                        <p>Generating a new QR immediately invalidates this one.</p>
                    </div>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?= e(url('/student/generate-qr.php')) ?>" data-loading>
                        <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                        <button type="submit" class="btn btn-secondary btn-block" id="regenerate-btn">
                            <?= icon('refresh', 'icon icon-sm') ?><span>Generate New QR</span>
                            <span class="spinner" aria-hidden="true"></span>
                        </button>
                    </form>
                </div>
            </section>
        <?php endif; ?>

        <section class="card" aria-labelledby="tips-heading">
            <div class="card-header">
                <div>
                    <h2 id="tips-heading">Keep your QR safe</h2>
                    <p>Your code works like a one-time key.</p>
                </div>
            </div>
            <div class="card-body">
                <ol class="steps-list">
                    <li><span><strong>It’s temporary</strong>Each code expires automatically after a few minutes.</span></li>
                    <li><span><strong>Don’t share it</strong>Never send screenshots or the manual-entry code to anyone.</span></li>
                    <li><span><strong>Verified by the server</strong>The countdown is a guide; the server checks the real expiry time when scanned.</span></li>
                </ol>
            </div>
        </section>
    </aside>
</div>
<?php renderPageEnd(['/assets/js/qrcode.min.js', '/assets/js/student-qr.js', '/assets/js/qr-countdown.js']); ?>
