<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../config/database.php';

// Already logged in -> skip straight to dashboard.
if (!empty($_SESSION['user_id'])) {
    header('Location: ' . dashboardPathForRole($_SESSION['role']));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
        $error = 'Invalid request. Please refresh the page and try again.';
    } else {
        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');

        if ($username === '' || $password === '') {
            $error = 'Username and password are required.';
        } else {
            $pdo = getDBConnection();

            $stmt = $pdo->prepare(
                'SELECT id, username, password_hash, role, status
                 FROM users
                 WHERE username = ?'
            );
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            // Same generic error whether the user doesn't exist or the
            // password is wrong -- never reveal which one it was.
            if (!$user || !password_verify($password, $user['password_hash'])) {
                $error = 'Invalid username or password.';
            } elseif ($user['status'] !== 'ACTIVE') {
                $error = 'This account is inactive. Please contact an administrator.';
            } else {
                // Prevent session fixation.
                session_regenerate_id(true);

                $_SESSION['user_id']  = (int) $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role']     = $user['role'];

                header('Location: ' . dashboardPathForRole($user['role']));
                exit;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#1e40af">
    <title>Sign in · Digital ID System</title>
    <link rel="stylesheet" href="<?= e(asset('/assets/css/style.css')) ?>">
</head>
<body class="auth-body">
<div class="auth-layout">
    <section class="auth-brand" aria-label="About the Digital ID System">
        <div class="sidebar-brand">
            <span class="brand-mark"><?= icon('id-card') ?></span>
            <span class="brand-text"><strong>Digital ID System</strong><small>Student Access Verification</small></span>
        </div>

        <div class="auth-brand-copy">
            <h2>Secure, contact-free campus access.</h2>
            <p>One portal for student digital IDs, temporary QR credentials and gate access records.</p>
            <ul class="auth-features">
                <li><?= icon('qr') ?><span>Temporary QR codes that expire automatically and carry no personal data.</span></li>
                <li><?= icon('scan') ?><span>Server-verified IN / OUT scanning at every entrance.</span></li>
                <li><?= icon('shield') ?><span>Role-based access for administrators, scanner staff and students.</span></li>
            </ul>
        </div>

        <p class="auth-brand-foot">Our Lady of Lourdes College &middot; Digital Identification System</p>
    </section>

    <main class="auth-panel">
        <div class="auth-card">
            <div class="sidebar-brand auth-card-brand">
                <span class="brand-mark"><?= icon('id-card') ?></span>
                <span class="brand-text"><strong>Digital ID System</strong><small>Student Access Verification</small></span>
            </div>

            <h1>Sign in</h1>
            <p class="auth-lead">Use the account issued to you by the school administrator.</p>

            <form class="auth-form" method="POST" action="<?= e(url('/auth/login.php')) ?>" data-loading>
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

                <?php if ($error !== ''): ?>
                    <?= renderAlert('error', $error) ?>
                <?php endif; ?>

                <div class="form-group">
                    <label class="form-label" for="username">Username</label>
                    <div class="input-group">
                        <?= icon('user', 'icon input-icon') ?>
                        <input class="form-control" type="text" id="username" name="username" required
                               autocomplete="username" autocapitalize="none" spellcheck="false"
                               <?= $error === '' ? 'autofocus' : '' ?>
                               <?= $error !== '' ? 'aria-invalid="true"' : '' ?>
                               value="<?= e($_POST['username'] ?? '') ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label" for="password">Password</label>
                    <div class="input-group has-action">
                        <?= icon('lock', 'icon input-icon') ?>
                        <input class="form-control" type="password" id="password" name="password" required
                               autocomplete="current-password"
                               <?= $error !== '' ? 'autofocus aria-invalid="true"' : '' ?>>
                        <button type="button" class="input-action" data-password-toggle aria-controls="password"
                                aria-label="Show password" aria-pressed="false" hidden>
                            <span data-icon="show"><?= icon('eye') ?></span>
                            <span data-icon="hide" hidden><?= icon('eye-off') ?></span>
                        </button>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-lg btn-block">
                    <span>Sign in</span>
                    <span class="spinner" aria-hidden="true"></span>
                </button>
            </form>

            <p class="auth-help">Forgot your password or locked out? Contact your system administrator.</p>
        </div>
    </main>
</div>
<script src="<?= e(asset('/assets/js/app.js')) ?>"></script>
</body>
</html>
