/**
 * Student QR page (student/generate-qr.php). Moved here unchanged in
 * behaviour from the page's former inline scripts:
 *   1. Renders the server-issued token in #qr-code-container as a QR image
 *      (assets/js/qrcode.min.js). Skipped safely if the library is missing.
 *   2. Select-all on focus + Copy button for the manual-entry token field.
 * The token itself is generated and validated only on the server.
 */
(function () {
    'use strict';

    var container = document.getElementById('qr-code-container');
    if (container && typeof QRCode !== 'undefined') {
        new QRCode(container, {
            text: container.dataset.qrValue,
            width: 264,
            height: 264
        });
    }

    var field = document.getElementById('qr-token-text');
    var button = document.getElementById('copy-token');
    var note = document.getElementById('copy-token-note');
    if (!field || !button) { return; }

    field.addEventListener('focus', function () { field.select(); });
    button.addEventListener('click', function () {
        field.select();
        var done = function (ok) { note.textContent = ok ? 'Copied to clipboard.' : 'Press Ctrl+C (or long-press) to copy.'; };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(field.value).then(function () { done(true); }, function () { done(false); });
        } else {
            var ok = false;
            try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
            done(ok);
        }
    });
})();
