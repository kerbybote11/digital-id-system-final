/**
 * Scanner page controller (scanner/scanner.php).
 *
 * Workflow:  choose SCAN IN / SCAN OUT  ->  camera or manual token
 *            ->  POST {csrf_token, action, qr_token} to scanner/verify.php
 *            ->  show the server's result.
 *
 * This script has NO authority over anything. It never decides whether a
 * token is valid or whether a student may go IN/OUT -- it only forwards the
 * token plus the operator's selected action, and displays whatever the server
 * decides. The server re-validates the role, CSRF token, action, token and the
 * student's current status on every request.
 */
(function () {
    'use strict';

    var app = document.getElementById('scanner-app');
    if (!app) { return; }

    var VALID_ACTIONS = ['IN', 'OUT'];
    var verifyUrl = app.getAttribute('data-verify-url');
    var csrfToken = app.getAttribute('data-csrf-token');

    var el = {
        stepAction:  document.getElementById('step-action'),
        stepScan:    document.getElementById('step-scan'),
        stepResult:  document.getElementById('step-result'),
        badge:       document.getElementById('selected-action-badge'),
        scanHeading: document.getElementById('scan-heading'),
        cameraBox:   document.getElementById('camera-box'),
        cameraArea:  document.getElementById('camera-scan-area'),
        cameraStatus: document.getElementById('camera-status'),
        cameraRetry: document.getElementById('camera-retry'),     // optional (UI refresh)
        resultReason: document.getElementById('result-reason'),   // optional (UI refresh)
        form:        document.getElementById('manual-form'),
        token:       document.getElementById('qr_token'),
        tokenError:  document.getElementById('token-error'),
        verifyBtn:   document.getElementById('verify-btn'),
        changeBtn:   document.getElementById('change-action'),
        resultIcon:  document.getElementById('result-icon'),
        resultTitle: document.getElementById('result-title'),
        resultStudent: document.getElementById('result-student'),
        resultMessage: document.getElementById('result-message'),
        resultDetails: document.getElementById('result-details'),
        scanNext:    document.getElementById('scan-next'),
        resultChange: document.getElementById('result-change-action')
    };

    // ---- state ---------------------------------------------------------
    var selectedAction = null;   // null | 'IN' | 'OUT'
    var phase = 'select';        // 'select' | 'scan' | 'result'
    var inFlight = false;        // a verify request is currently running
    var reloadOnNext = false;    // result needs a page reload (expired session / CSRF)

    // ---- small helpers -------------------------------------------------
    function showOnly(section) {
        el.stepAction.hidden = section !== el.stepAction;
        el.stepScan.hidden   = section !== el.stepScan;
        el.stepResult.hidden = section !== el.stepResult;
    }

    function setCameraStatus(message, isProblem) {
        el.cameraStatus.textContent = message || '';
        el.cameraStatus.classList.toggle('is-problem', !!isProblem);
    }

    function clearTokenError() {
        el.tokenError.hidden = true;
        el.tokenError.textContent = '';
        el.token.removeAttribute('aria-invalid');
    }

    function showTokenError(message) {
        el.tokenError.textContent = message;
        el.tokenError.hidden = false;
        el.token.setAttribute('aria-invalid', 'true');
    }

    function setBusy(busy) {
        el.verifyBtn.disabled = busy;
        el.verifyBtn.classList.toggle('is-loading', busy);
        el.verifyBtn.setAttribute('aria-busy', busy ? 'true' : 'false');
        el.token.readOnly = busy;
        el.changeBtn.disabled = busy;          // never abandon a request that may record a transaction
        el.resultChange.disabled = busy;
        if (busy) { setCameraStatus('Verifying\u2026'); }
    }

    function badgeClass(status) {
        return 'badge ' + (status === 'IN' ? 'badge-in' : status === 'OUT' ? 'badge-out' : '');
    }

    // ---- camera lifecycle ---------------------------------------------
    function stopCamera() {
        if (window.QrCameraScanner) { window.QrCameraScanner.stop(); }
    }

    // "Try camera again" is only offered when retrying can actually help
    // (permission denied, camera busy...), not when the browser can't scan.
    function setRetryVisible(visible) {
        if (!el.cameraRetry) { return; }
        var canRetry = visible && window.QrCameraScanner && window.QrCameraScanner.isSupported().supported;
        el.cameraRetry.hidden = !canRetry;
    }

    function startCamera() {
        // The camera only ever starts while an action is selected.
        if (!selectedAction || phase !== 'scan') { return; }

        setRetryVisible(false);
        el.cameraBox.classList.remove('is-off');
        if (!window.QrCameraScanner) {
            el.cameraBox.classList.add('is-off');
            setCameraStatus('Camera scanner is unavailable. Enter the token manually.', true);
            return;
        }
        window.QrCameraScanner.start(el.cameraArea, {
            onStatus: function (message) { setCameraStatus(message, false); },
            onError: function (message) {
                el.cameraBox.classList.add('is-off');
                setCameraStatus(message, true);
                setRetryVisible(true);
            },
            onDetect: function (text) { submitToken(text); }
        });
    }

    // ---- action selection ---------------------------------------------
    function selectAction(action) {
        if (VALID_ACTIONS.indexOf(action) === -1) { return; }
        selectedAction = action;
        phase = 'scan';
        reloadOnNext = false;

        el.token.value = '';
        clearTokenError();
        setCameraStatus('');
        el.badge.textContent = action;
        el.badge.className = badgeClass(action);
        showOnly(el.stepScan);
        el.scanHeading.focus();
        startCamera();
    }

    function changeAction() {
        if (inFlight) { return; }
        stopCamera();
        setRetryVisible(false);
        selectedAction = null;                 // the previous action can never leak into the next scan
        phase = 'select';
        reloadOnNext = false;
        el.token.value = '';                   // nor can the previous token
        clearTokenError();
        setCameraStatus('');
        showOnly(el.stepAction);
    }

    function scanNext() {
        if (reloadOnNext) { window.location.reload(); return; }
        if (!selectedAction) { changeAction(); return; }
        phase = 'scan';
        clearTokenError();
        showOnly(el.stepScan);
        el.scanHeading.focus();
        startCamera();
    }

    // ---- verify (shared by camera scans and manual entry) -------------
    function submitToken(rawToken) {
        // Hard stop: no action selected (or something tampered with the UI).
        if (VALID_ACTIONS.indexOf(selectedAction) === -1) {
            stopCamera();
            return;
        }
        if (inFlight) { return; }              // prevents double submission

        var token = String(rawToken || '').trim();
        if (token === '') {
            showTokenError('Enter or scan a token first.');
            return;
        }

        clearTokenError();
        var action = selectedAction;           // captured now; the server re-validates it
        inFlight = true;
        stopCamera();
        setRetryVisible(false);
        setBusy(true);

        var body = new URLSearchParams();
        body.set('csrf_token', csrfToken);
        body.set('action', action);
        body.set('qr_token', token);

        fetch(verifyUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString()
        }).then(function (response) {
            return response.json().then(
                function (data) { return { status: response.status, data: data }; },
                function () { return { status: response.status, data: null }; }
            );
        }).then(function (result) {
            var data = result.data;
            if (!data || typeof data.title !== 'string') {
                data = {
                    severity: 'error', title: 'SYSTEM ERROR',
                    message: 'The server sent an unexpected response. Please try again.'
                };
            }
            el.token.value = '';               // definitive answer received: never reuse this token
            reloadOnNext = result.status === 401 || result.status === 403;
            showResult(data, action);
        }).catch(function () {
            // Network failure: nothing was confirmed, so keep the typed token for a retry.
            showResult({
                severity: 'error', title: 'CONNECTION PROBLEM',
                message: 'Could not reach the server. Check the connection and try again.'
            }, action);
        }).then(function () {
            inFlight = false;
            setBusy(false);
            setCameraStatus('');
        });
    }

    // ---- result screen -------------------------------------------------
    var REASON_LABELS = {
        SUCCESS_IN: 'Entry recorded',
        SUCCESS_OUT: 'Exit recorded',
        ALREADY_IN: 'Already inside',
        ALREADY_OUT: 'Already outside',
        TOKEN_EXPIRED: 'QR expired',
        TOKEN_REVOKED: 'QR revoked',
        TOKEN_INVALID: 'QR not recognised',
        STUDENT_INACTIVE: 'Inactive account',
        INVALID_ACTION: 'No action selected',
        SYSTEM_ERROR: 'System error',
        AUTH_REQUIRED: 'Session expired',
        FORBIDDEN: 'Not permitted',
        CSRF_INVALID: 'Page out of date'
    };

    function addDetail(label, value, status) {
        var dt = document.createElement('dt');
        dt.textContent = label;
        var dd = document.createElement('dd');
        if (status) {
            var badge = document.createElement('span');
            badge.className = badgeClass(status);
            badge.textContent = status;
            dd.appendChild(badge);
        } else {
            dd.textContent = value;
        }
        el.resultDetails.appendChild(dt);
        el.resultDetails.appendChild(dd);
    }

    function showResult(data, action) {
        var severity = ['success', 'warning', 'error'].indexOf(data.severity) !== -1 ? data.severity : 'error';
        var student = data.student || null;

        phase = 'result';
        el.stepResult.className = 'scanner-card result-card result-' + severity;
        el.stepResult.setAttribute('role', severity === 'success' ? 'status' : 'alert');
        el.resultIcon.textContent = severity === 'success' ? '\u2713' : severity === 'warning' ? '\u26A0' : '\u2715';
        el.resultTitle.textContent = data.title;

        // Short reason label so similar-looking outcomes (expired, revoked,
        // inactive, unknown) are distinguishable at a glance. Display only.
        if (el.resultReason) {
            var reason = REASON_LABELS[data.code] || '';
            el.resultReason.textContent = reason;
            el.resultReason.className = 'badge badge-plain result-reason ' +
                (severity === 'success' ? 'badge-success' : severity === 'warning' ? 'badge-warning' : 'badge-danger');
            el.resultReason.hidden = !reason;
        }

        // Success: big student name. Warning/error: the explanatory message.
        el.resultStudent.textContent = severity === 'success' && student ? student.name : '';
        el.resultStudent.hidden = !el.resultStudent.textContent;
        el.resultMessage.textContent = severity === 'success' ? '' : (data.message || '');
        el.resultMessage.hidden = !el.resultMessage.textContent;

        while (el.resultDetails.firstChild) { el.resultDetails.removeChild(el.resultDetails.firstChild); }
        if (severity === 'success' && student) {
            addDetail('Student ID', student.student_id);
            addDetail('Course', student.course + ' \u2022 ' + student.year_level);
            addDetail('Status', '', data.current_status);
            addDetail('Time', data.time || '');
            addDetail('Action', data.action_label || '');
        } else if (severity === 'warning') {
            addDetail('Current Status', '', data.current_status);
            addDetail('Selected Action', data.action || action);
        }
        el.resultDetails.hidden = !el.resultDetails.firstChild;

        el.scanNext.textContent = reloadOnNext
            ? 'Reload Page'
            : (severity === 'success' ? 'Scan Next' : 'Try Again') + ' (' + (action || selectedAction) + ')';
        el.resultChange.hidden = reloadOnNext;

        showOnly(el.stepResult);
        el.resultTitle.focus();
    }

    // ---- wiring --------------------------------------------------------
    Array.prototype.forEach.call(el.stepAction.querySelectorAll('[data-action]'), function (btn) {
        btn.addEventListener('click', function () { selectAction(btn.getAttribute('data-action')); });
    });
    el.changeBtn.addEventListener('click', changeAction);
    el.resultChange.addEventListener('click', changeAction);
    el.scanNext.addEventListener('click', scanNext);
    if (el.cameraRetry) {
        el.cameraRetry.addEventListener('click', function () {
            if (!inFlight && phase === 'scan') { startCamera(); }
        });
    }
    el.form.addEventListener('submit', function (event) {
        event.preventDefault();
        submitToken(el.token.value);
    });
    el.token.addEventListener('input', clearTokenError);

    // Don't leave the camera running while the tab is hidden / page is leaving.
    document.addEventListener('visibilitychange', function () {
        if (document.hidden) {
            stopCamera();
        } else if (phase === 'scan' && !inFlight) {
            startCamera();
        }
    });
    window.addEventListener('pagehide', stopCamera);
})();
