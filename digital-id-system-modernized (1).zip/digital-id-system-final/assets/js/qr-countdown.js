/**
 * Purely cosmetic countdown for the student's QR page. This has NO
 * authority over whether a QR is actually valid -- the server independently
 * re-checks expiration on every scan attempt (see includes/qr.php). If this
 * script fails to load, is blocked, or is tampered with client-side, the
 * server's own expiration check still applies.
 *
 * Preferred input: data-seconds-left / data-lifetime, computed by MySQL when
 * the page was rendered, so the timer is correct even if the device's clock
 * or time zone differs from the server's. Falls back to parsing
 * data-expires-at ("YYYY-MM-DD HH:MM:SS", server local time) as before.
 *
 * On expiry it only changes what is displayed (overlay, badge, message).
 */
(function () {
    const el = document.getElementById('qr-countdown');
    if (!el) return;

    const panel = document.getElementById('qr-panel');
    const bar = document.getElementById('qr-progress');
    const badge = document.getElementById('qr-status-badge');
    const announce = document.getElementById('qr-expiry-announce');
    const label = document.getElementById('qr-countdown-label');

    const secondsAttr = parseInt(el.dataset.secondsLeft, 10);
    const lifetime = Math.max(1, parseInt(el.dataset.lifetime, 10) || 0);
    let expiresAtMs;
    if (!isNaN(secondsAttr)) {
        expiresAtMs = Date.now() + secondsAttr * 1000;
    } else {
        expiresAtMs = new Date(el.dataset.expiresAt.replace(' ', 'T')).getTime();
    }

    let intervalId = null;

    function markExpired() {
        el.textContent = 'Expired';
        el.classList.add('qr-expired');
        if (label) { label.textContent = 'Status'; }
        if (bar) { bar.style.width = '0%'; }
        if (panel) { panel.classList.add('is-expired'); }
        if (badge) {
            badge.className = 'badge badge-warning';
            badge.textContent = 'Expired';
        }
        if (announce) {
            announce.textContent = 'Your QR code has expired. Generate a new one to continue.';
        }
        if (intervalId !== null) { clearInterval(intervalId); }
    }

    function tick() {
        const diffMs = expiresAtMs - Date.now();

        if (diffMs <= 0) {
            markExpired();
            return;
        }

        const totalSeconds = Math.floor(diffMs / 1000);
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = totalSeconds % 60;
        el.textContent = String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');

        if (bar) {
            const pct = Math.max(0, Math.min(100, (totalSeconds / lifetime) * 100));
            bar.style.width = pct + '%';
            bar.classList.toggle('is-low', totalSeconds <= 60 && totalSeconds > 20);
            bar.classList.toggle('is-critical', totalSeconds <= 20);
        }
    }

    tick();
    if (!el.classList.contains('qr-expired')) {
        intervalId = setInterval(tick, 1000);
    }
})();
