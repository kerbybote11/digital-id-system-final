/**
 * Shared UI behaviour for every page (loaded by includes/layout.php and
 * auth/login.php). Progressive enhancement only: every page still works
 * without this file, and nothing here makes security decisions -- the
 * server re-checks permissions, CSRF tokens and input on every request.
 *
 *   [data-nav-toggle] / [data-nav-close]   mobile sidebar drawer
 *   details.account-menu                   closes on outside click / Esc
 *   [data-dismiss-alert]                   dismissible alerts
 *   form[data-confirm]                     confirmation dialog before submit
 *   [data-password-toggle]                 show / hide password inputs
 *   form[data-loading]                     disable + spinner on submit
 */
(function () {
    'use strict';

    // ---- mobile navigation drawer ---------------------------------------
    var sidebar = document.getElementById('app-sidebar');
    var backdrop = document.querySelector('.sidebar-backdrop');
    var toggle = document.querySelector('[data-nav-toggle]');
    var lastFocus = null;

    function setNav(open) {
        if (!sidebar || !toggle) { return; }
        sidebar.classList.toggle('is-open', open);
        toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (backdrop) { backdrop.hidden = !open; }
        if (open) {
            lastFocus = document.activeElement;
            var first = sidebar.querySelector('.nav-link.is-active, .nav-link');
            if (first) { first.focus(); }
        } else if (lastFocus && typeof lastFocus.focus === 'function') {
            lastFocus.focus();
            lastFocus = null;
        }
    }

    if (toggle) {
        toggle.addEventListener('click', function () {
            setNav(!sidebar.classList.contains('is-open'));
        });
    }
    Array.prototype.forEach.call(document.querySelectorAll('[data-nav-close]'), function (btn) {
        btn.addEventListener('click', function () { setNav(false); });
    });

    // Close the drawer when the viewport grows to the desktop layout.
    if (window.matchMedia) {
        var desktop = window.matchMedia('(min-width: 1024px)');
        var onChange = function (e) { if (e.matches && sidebar && sidebar.classList.contains('is-open')) { setNav(false); } };
        if (desktop.addEventListener) { desktop.addEventListener('change', onChange); }
        else if (desktop.addListener) { desktop.addListener(onChange); }
    }

    // ---- account menu ----------------------------------------------------
    var accountMenus = document.querySelectorAll('details.account-menu');
    document.addEventListener('click', function (e) {
        Array.prototype.forEach.call(accountMenus, function (menu) {
            if (menu.open && !menu.contains(e.target)) { menu.open = false; }
        });
    });

    document.addEventListener('keydown', function (e) {
        if (e.key !== 'Escape') { return; }
        if (sidebar && sidebar.classList.contains('is-open')) { setNav(false); }
        Array.prototype.forEach.call(accountMenus, function (menu) {
            if (menu.open) {
                menu.open = false;
                var summary = menu.querySelector('summary');
                if (summary) { summary.focus(); }
            }
        });
    });

    // ---- dismissible alerts ---------------------------------------------
    document.addEventListener('click', function (e) {
        var btn = e.target.closest ? e.target.closest('[data-dismiss-alert]') : null;
        if (!btn) { return; }
        var alert = btn.closest('.alert');
        if (alert) { alert.parentNode.removeChild(alert); }
    });

    // ---- confirmation dialogs -------------------------------------------
    // <form data-confirm="Message" data-confirm-title="Title"
    //       data-confirm-ok="Button label" data-confirm-variant="danger|primary">
    var dialog = document.getElementById('confirm-dialog');
    var pendingForm = null;

    function openConfirm(form) {
        var message = form.getAttribute('data-confirm') || 'Are you sure?';
        var title = form.getAttribute('data-confirm-title') || 'Please confirm';
        var okLabel = form.getAttribute('data-confirm-ok') || 'Confirm';
        var variant = form.getAttribute('data-confirm-variant') === 'primary' ? 'primary' : 'danger';

        if (!dialog || typeof dialog.showModal !== 'function') {
            // Older browsers: native confirm keeps the safeguard in place.
            if (window.confirm(title + '\n\n' + message)) { form.submit(); }
            return;
        }

        pendingForm = form;
        dialog.setAttribute('data-variant', variant);
        document.getElementById('confirm-title').textContent = title;
        document.getElementById('confirm-message').textContent = message;
        var ok = document.getElementById('confirm-ok');
        ok.textContent = okLabel;
        ok.className = 'btn ' + (variant === 'primary' ? 'btn-primary' : 'btn-danger');
        dialog.returnValue = '';
        dialog.showModal();
        document.getElementById('confirm-cancel').focus();   // safe default
    }

    if (dialog) {
        dialog.addEventListener('close', function () {
            var form = pendingForm;
            pendingForm = null;
            if (form && dialog.returnValue === 'confirm') {
                var btn = form.querySelector('[type="submit"]');
                if (btn) { btn.disabled = true; btn.classList.add('is-loading'); }
                form.submit();   // bypasses the submit listener below
            }
        });
        // Clicking the backdrop cancels.
        dialog.addEventListener('click', function (e) {
            if (e.target === dialog) { dialog.close('cancel'); }
        });
    }

    document.addEventListener('submit', function (e) {
        var form = e.target;
        if (form.hasAttribute('data-confirm')) {
            e.preventDefault();
            openConfirm(form);
            return;
        }
        if (form.hasAttribute('data-loading')) {
            if (form.getAttribute('data-submitting') === 'true') { e.preventDefault(); return; }
            if (typeof form.checkValidity === 'function' && !form.noValidate && !form.checkValidity()) { return; }
            form.setAttribute('data-submitting', 'true');
            var submit = form.querySelector('[type="submit"]');
            if (submit) {
                // Defer so the browser has already captured the form data.
                setTimeout(function () {
                    submit.disabled = true;
                    submit.classList.add('is-loading');
                    submit.setAttribute('aria-busy', 'true');
                }, 0);
            }
        }
    });

    // Restore buttons if the page is shown again from the back/forward cache.
    window.addEventListener('pageshow', function (e) {
        if (!e.persisted) { return; }
        Array.prototype.forEach.call(document.querySelectorAll('form[data-submitting]'), function (form) {
            form.removeAttribute('data-submitting');
            var submit = form.querySelector('[type="submit"]');
            if (submit) {
                submit.disabled = false;
                submit.classList.remove('is-loading');
                submit.removeAttribute('aria-busy');
            }
        });
    });

    // ---- password visibility toggle --------------------------------------
    Array.prototype.forEach.call(document.querySelectorAll('[data-password-toggle]'), function (btn) {
        var input = document.getElementById(btn.getAttribute('aria-controls'));
        if (!input) { return; }
        var showIcon = btn.querySelector('[data-icon="show"]');
        var hideIcon = btn.querySelector('[data-icon="hide"]');
        btn.hidden = false;
        btn.addEventListener('click', function () {
            var reveal = input.type === 'password';
            input.type = reveal ? 'text' : 'password';
            btn.setAttribute('aria-pressed', reveal ? 'true' : 'false');
            btn.setAttribute('aria-label', reveal ? 'Hide password' : 'Show password');
            if (showIcon) { showIcon.hidden = reveal; }
            if (hideIcon) { hideIcon.hidden = !reveal; }
        });
    });
})();
