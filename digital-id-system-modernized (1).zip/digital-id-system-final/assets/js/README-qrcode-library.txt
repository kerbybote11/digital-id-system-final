qrcode.min.js is now included locally in this project (no CDN required,
works fully offline).

What it is: a self-contained, from-scratch QR-code renderer scoped
specifically to this project's needs -- it only ever encodes the fixed-
length 64-character opaque token this system generates (see
includes/qr.php). It implements one fixed configuration: QR Version 4,
error-correction level L, Byte mode, a fixed (spec-valid) mask pattern.
It does not attempt to be a general-purpose QR library.

How it was verified (no live browser/scanner was available while building
it): Reed-Solomon codeword divisibility was verified computationally
(a valid RS codeword evaluates to zero at every root of the generator
polynomial); the format-info BCH encoding was verified by round-trip
(re-running the same remainder computation over the final bits yields
zero); every data-region module was confirmed filled exactly once with no
gaps or collisions; and the actual shipped file's rendered SVG output was
diffed byte-for-byte against an independently built reference
implementation, with zero differences across all 1089 grid cells.

What was NOT verified: an actual physical camera/phone scan of a rendered
code. Please confirm a real phone scans it correctly once you're on your
own XAMPP/browser environment -- if it doesn't, that's a concrete defect
to report rather than something to assume is fine.

Usage (unchanged from before): new QRCode(container, { text, width, height }).
