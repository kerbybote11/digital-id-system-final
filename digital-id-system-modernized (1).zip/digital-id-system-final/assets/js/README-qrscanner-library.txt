qrscanner.min.js is included locally in this project (no CDN required).

What it is: NOT a bundled third-party decoding library. It uses the
browser's own native BarcodeDetector API to read QR codes from the device
camera. A hand-written image decoder (finder patterns, perspective
correction, Reed-Solomon) is large and easy to get subtly wrong, so this
project relies on the browser-vendor-maintained API instead.

How it is used now: the camera does NOT start when the page loads.
scanner/scanner.php (via assets/js/scanner.js) calls
    QrCameraScanner.start(container, { onDetect, onStatus, onError })
only AFTER the operator has chosen SCAN IN or SCAN OUT, and calls
    QrCameraScanner.stop()
on Change Action, after a successful decode, when the tab is hidden, and on
errors. QrCameraScanner.isSupported() reports whether the browser can scan.

Browser support: Chrome/Edge/Opera on Android, and Chromium on macOS/ChromeOS,
implement BarcodeDetector with 'qr_code'. Chrome/Edge on Windows and Linux
may NOT expose it by default, and Firefox and Safari do not implement it. Where it
isn't available (or camera permission is denied / not HTTPS or localhost),
the page shows a message and the manual token field -- which uses exactly the
same server-side verification -- remains fully usable.

If you need camera scanning on browsers without BarcodeDetector, a pure-JS
decoder can be dropped in behind the same start()/stop() API without
touching scanner.js or any server code.

This file never decides whether a QR is valid; it only extracts text and
hands it to onDetect(). The server is the sole authority (scanner/verify.php
-> performScanAction() in includes/access.php).
